<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'farm.create')): ?>
<h2>Crear finca</h2>
<?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php echo $__env->make('farm.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<button wire:click="store" class="btn btn-outline-primary" id="createFarm" data-toggle="tooltip" data-placement="top" title="Crear Finca">
    <i class="fas fa-plus-circle"></i> Crear
</button>
<?php endif; ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/farm/create.blade.php ENDPATH**/ ?>