<div class="row">
    <div class="col-md-6 form-group">
        <?php echo e(Form::label('name', 'Nonbre de Marcación', ['class' => 'control-label'])); ?>

        <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="name">
    </div>
    <div class="col-md-3 form-group">
        <?php echo e(Form::label('phone', 'Teléfono', ['class' => 'control-label'])); ?>

        <input type="text" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="phone">
    </div>
    <div class="col-md-3 form-group">
        <?php echo e(Form::label('email', 'Correo', ['class' => 'control-label'])); ?>

        <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="email">
    </div>
    <div class="col-md-6 form-group">
        <?php echo e(Form::label('address', 'Dirección', ['class' => 'control-label'])); ?>

        <input type="text" name="address" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="address">
    </div>
    <div class="col-md-2 form-group">
        <?php echo e(Form::label('state', 'Estado', ['class' => 'control-label'])); ?>

        <input type="text" name="state" class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="state">
    </div>
    <div class="col-md-2 form-group">
        <?php echo e(Form::label('city', 'Ciudad', ['class' => 'control-label'])); ?>

        <input type="text" name="city" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="city">
    </div>
    <div class="col-md-2 form-group">
        <?php echo e(Form::label('country', 'País', ['class' => 'control-label'])); ?>

        <input type="text" name="country" class="form-control <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="country">
    </div>
    <div class="col-md-4 form-group">
        <?php echo e(Form::label('owner', 'Propieatrio', ['class' => 'control-label'])); ?>

        <input type="text" name="owner" class="form-control <?php $__errorArgs = ['owner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="owner">
    </div>
    <div class="col-md-4 form-group">
        <?php echo e(Form::label('sub_owner', 'Sub Propieatrio', ['class' => 'control-label'])); ?>

        <input type="text" name="sub_owner" class="form-control <?php $__errorArgs = ['sub_owner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="sub_owner">
    </div>
    <div class="col-md-2 form-group">
        <?php echo e(Form::label('sub_owner_phone', 'Teléfono Sub Propieatrio', ['class' => 'control-label'])); ?>

        <input type="text" name="sub_owner_phone" class="form-control <?php $__errorArgs = ['sub_owner_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="sub_owner_phone">
    </div>
    <div class="col-md-6 form-group">
        <?php echo e(Form::label('related_names', 'Nombres Relacionados', ['class' => 'control-label'])); ?>

        <input type="text" name="related_names" class="form-control <?php $__errorArgs = ['related_names'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="related_names">
    </div>
    <div class="col-md-4 form-group">
        <?php echo e(Form::label('buyer', 'Broker/Comprador', ['class' => 'control-label'])); ?>

        <input type="text" name="buyer" class="form-control <?php $__errorArgs = ['buyer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="buyer">
    </div>
    <div class="col-md-3 form-group">
        <?php echo e(Form::label('type_load', 'Tipo de Carga', ['class' => 'control-label'])); ?>

        <select name="type_load" id="type_load" class="custom-select  <?php $__errorArgs = ['type_load'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="type_load">
            <option value="">Seleccione Tipo de Carga</option>
            <option value="AEREO">AÉREO</option>
            <option value="MARITIMO">MARÍTIMO</option>
            <option value="AEREO/MARITIMO">AÉREO/MARÍTIMO</option>
        </select>
    </div>
    <div class="col-md-3 form-group">
        <?php echo e(Form::label('delivery', 'Delivery/Pick Up', ['class' => 'control-label'])); ?>

        <select name="delivery" id="delivery" class="custom-select  <?php $__errorArgs = ['delivery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="delivery">
            <option value="">Seleccione Delivery/Pick Up</option>
            <option value="BODEGA LOS ANGELES">BODEGA LOS ANGELES</option>
            <option value="EDG LOGISTIC">EDG LOGISTIC</option>
            <option value="DIRECTO CLIENTE">DIRECTO CLIENTE</option>
            <option value="POMONA">POMONA</option>
        </select>
    </div>
    <div class="col-md-3 form-group">
        <?php echo e(Form::label('method_payment', 'Forma de Pago', ['class' => 'control-label'])); ?>

        <select name="method_payment" id="method_payment" class="custom-select  <?php $__errorArgs = ['method_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="method_payment">
            <option value="">Seleccione Forma de Pago</option>
            <option value="EFECTIVO">EFECTIVO</option>
            <option value="CHEQUE">CHEQUE</option>
            <option value="ZELLER">ZELLER</option>
        </select>
    </div>
    <div class="col-md-12 form-group">
        <?php echo e(Form::label('poa', 'POA', ['class' => 'control-label'])); ?>

    </div>
    <div class="col-md-2 form-group">
        <div class="form-check form-check-inline">
            <input class="form-check-input <?php $__errorArgs = ['poa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio" name="poa" id="yes" wire:model="poa" value="yes">
            <label class="form-check-label" for="yes">Si</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input <?php $__errorArgs = ['poa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio" name="poa" id="no" wire:model="poa" value="no">
            <label class="form-check-label" for="no">No</label>
        </div>
    </div>
</div>
<?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/client/form.blade.php ENDPATH**/ ?>