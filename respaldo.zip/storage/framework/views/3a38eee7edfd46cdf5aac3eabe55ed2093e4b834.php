<div class="form-row">
   <div class="form-group col-md-4">
      <?php echo e(Form::label('shipment', 'Carga')); ?>

      <?php echo e(Form::text('shipment', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-4">
      <?php echo e(Form::label('bl', 'BL')); ?>

      <?php echo e(Form::text('bl', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-4">
      <?php echo e(Form::label('carrier', 'Transportista')); ?>

      <?php echo e(Form::text('carrier', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-4">
      <?php echo e(Form::label('date', 'Fecha Salida')); ?>

      <?php echo e(Form::date('date', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-4">
      <?php echo e(Form::label('arrival_date', 'Fecha llegada')); ?>

      <?php echo e(Form::date('arrival_date', null, ['class' => 'form-control'])); ?>

   </div>
   
   <div class="form-group col-md-6">
      <?php echo e(Form::label('code_deep', 'Código Termografo Fondo')); ?>

      <?php echo e(Form::text('code_deep', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-6">
      <?php echo e(Form::label('brand_deep', 'Marca Termografo Fondo')); ?>

      <?php echo e(Form::text('brand_deep', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-6">
      <?php echo e(Form::label('code_door', 'Código Termografo Puerta')); ?>

      <?php echo e(Form::text('code_door', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-6">
      <?php echo e(Form::label('brand_door', 'Marca Termografo Puerta')); ?>

      <?php echo e(Form::text('brand_door', null, ['class' => 'form-control'])); ?>

   </div>
   <?php echo e(Form::hidden('id_user', Auth::user()->id)); ?>

   <?php echo e(Form::hidden('update_user', Auth::user()->id)); ?>

</div>
    <?php /**PATH C:\laragon\www\app-ffc\resources\views/load/partials/form.blade.php ENDPATH**/ ?>