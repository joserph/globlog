

<?php $__env->startSection('title'); ?> Colores | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1>Colores
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'color.create')): ?>
                  <a href="<?php echo e(route('color.create')); ?>" class="btn btn-outline-primary"><i class="fas fa-plus-circle"></i></a>
               <?php endif; ?>
            </h1>
         </div>
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item active">Colores</li>
            </ol>
         </div>
      </div>
   </div><!-- /.container-fluid -->
</section>

<section class="content">
   <div class="container-fluid">
      <div class="row">
         <!-- /.col -->
         <div class="col-md-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'color.index')): ?>
               <div class="card">
                  <div class="card-header">
                     <h3 class="card-title">Lista de Colores</h3>
                     <div class="card-tools">
                        <?php echo e($colors->links()); ?>

                     </div>
                  </div>
   
                  <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
   
                  <!-- /.card-header -->
                  <div class="card-body table-responsive p-0">
                     <table class="table table-sm">
                        <thead class="thead-dark">
                           <tr>
                              <th scope="col">Tipo</th>
                              <th scope="col">Nombre</th>
                              <th scope="col">Color</th>
                              <th scope="col">Etiqueta</th>
                              <th class="text-center" width="80px" colspan="2"><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'color.edit')): ?>Editar <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'color.destroy')): ?>Eliminar <?php endif; ?></th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                 <td>
                                    <?php if($color->type == 'client'): ?>
                                       Cliente
                                    <?php else: ?> 
                                       Finca
                                    <?php endif; ?>
                                 </td>
                                 <td>
                                    <?php if($color->type == 'client'): ?>
                                       <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($color->id_type == $item->id): ?>
                                             <?php echo e($item->name); ?>

                                          <?php endif; ?>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                       <?php $__currentLoopData = $farms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($color->id_type == $farm->id): ?>
                                             <?php echo e($farm->name); ?>

                                          <?php endif; ?>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                 </td>
                                 <td>
                                    <svg width="20" height="20">
                                       <circle cx="15" cy="15" r="25" stroke="black" stroke-width="4" fill="<?php echo e($color->color); ?>" />
                                       Sorry, your browser does not support inline SVG.
                                    </svg>
                                 </td>
                                 <td>
                                    <?php if($color->label == 'square'): ?>
                                       <h5><span class="badge badge-success">Cuadrado</span></h5>
                                    <?php else: ?> 
                                       <h5><span class="badge badge-warning">Punto</span></h5>
                                    <?php endif; ?>
                                 </td>
                                 <td width="45px" class="text-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'color.edit')): ?>
                                       <a href="<?php echo e(route('color.edit', $color->id)); ?>" class="btn btn-outline-warning btn-sm"><i class="fas fa-edit"></i></a>
                                    <?php endif; ?>
                                 </td>
                                 <td width="45px" class="text-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'color.destroy')): ?>
                                       <?php echo e(Form::open(['route' => ['color.destroy', $color->id], 'method' => 'DELETE'])); ?>

                                          <?php echo e(Form::button('<i class="fas fa-trash-alt"></i> ' . '', ['type' => 'submit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'title' => 'Eliminar Vuelo', 'class' => 'btn btn-sm btn-outline-danger', 'onclick' => 'return confirm("¿Seguro de eliminar el color?")'])); ?>

                                       <?php echo e(Form::close()); ?>

                                    <?php endif; ?>
                                 </td>
                              </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     </table>
                  </div>
                  <!-- /.card-body -->
               </div>
            <?php endif; ?>
            <!-- /.card -->
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/color/index.blade.php ENDPATH**/ ?>