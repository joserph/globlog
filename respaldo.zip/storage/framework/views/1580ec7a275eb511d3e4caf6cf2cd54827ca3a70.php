<div class="row">
    <div class="col-md-6 form-group">
        <?php echo e(Form::label('name', 'Variedad', ['class' => 'control-label'])); ?>

        <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="name">
    </div>

    <div class="col-md-6 form-group">
        <?php echo e(Form::label('scientific_name', 'Nombre Cientifico', ['class' => 'control-label'])); ?>

        <input type="text" name="scientific_name" class="form-control <?php $__errorArgs = ['scientific_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="scientific_name">
    </div>
</div>

<?php /**PATH C:\laragon\www\app-ffc\resources\views/variety/form.blade.php ENDPATH**/ ?>