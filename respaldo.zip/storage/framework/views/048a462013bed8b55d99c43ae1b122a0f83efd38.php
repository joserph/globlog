

<?php $__env->startSection('title'); ?> Fincas | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'farms')): ?>

<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            
         </div>
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item active">Fincas</li>
            </ol>
         </div>
      </div>
   </div><!-- /.container-fluid -->
</section>

  <!-- Main content -->
<section class="content">
   <div class="container-fluid">
      <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('farm-component')->html();
} elseif ($_instance->childHasBeenRendered('Fs7st0l')) {
    $componentId = $_instance->getRenderedChildComponentId('Fs7st0l');
    $componentTag = $_instance->getRenderedChildComponentTagName('Fs7st0l');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Fs7st0l');
} else {
    $response = \Livewire\Livewire::mount('farm-component');
    $html = $response->html();
    $_instance->logRenderedChild('Fs7st0l', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/farm/farms.blade.php ENDPATH**/ ?>