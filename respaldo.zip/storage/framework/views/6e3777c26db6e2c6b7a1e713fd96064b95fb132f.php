

<?php $__env->startSection('title'); ?> Variedades | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'varieties')): ?>

<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            
         </div>
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item active">Variedades</li>
            </ol>
         </div>
      </div>
   </div><!-- /.container-fluid -->
</section>

  <!-- Main content -->
<section class="content">
   <div class="container-fluid">
      <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('variety-component')->html();
} elseif ($_instance->childHasBeenRendered('ISzHktv')) {
    $componentId = $_instance->getRenderedChildComponentId('ISzHktv');
    $componentTag = $_instance->getRenderedChildComponentTagName('ISzHktv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ISzHktv');
} else {
    $response = \Livewire\Livewire::mount('variety-component');
    $html = $response->html();
    $_instance->logRenderedChild('ISzHktv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/variety/varieties.blade.php ENDPATH**/ ?>