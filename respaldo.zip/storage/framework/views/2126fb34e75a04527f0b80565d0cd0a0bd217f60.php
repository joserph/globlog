<div class="row">
    <div class="col-md-12">
        <?php echo $__env->make("farm.$view", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-md-12">
        <hr>
    </div>
    <div class="col-md-12">
        <?php echo $__env->make('farm.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\app-ffc\resources\views/livewire/farm-component.blade.php ENDPATH**/ ?>