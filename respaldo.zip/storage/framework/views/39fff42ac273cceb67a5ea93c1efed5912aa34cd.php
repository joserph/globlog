

<?php $__env->startSection('title'); ?> Paletas | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1>Paletas
            </h1>
         </div>
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item"><a href="<?php echo e(route('load.index')); ?>">Cargas</a></li>
               <li class="breadcrumb-item"><a href="<?php echo e(route('load.show', $load->id)); ?>"><?php echo e($load->bl); ?></a></li>
               <li class="breadcrumb-item active">Paletas</li>
            </ol>
         </div>
      </div>
   </div><!-- /.container-fluid -->
</section>
<section class="content">
   <div class="container-fluid">
      <div class="row justify-content-center">
         <div class="col-sm">
            <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            <h4>Paletas ingresadas contenedor #<?php echo e($load->shipment); ?></h4>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'pallets.create')): ?>
               <button type="button" class="btn btn-xs btn-primary pull-right" data-toggle="modal" data-target="#myModal" data-toggle="tooltip" data-placement="top" title="Agregar nuevas paletas"><i class="fas fa-plus-circle"></i> Agregar Paleta</button>
            <?php endif; ?>
            <a href="<?php echo e(route('reports-client.excel', $load->id)); ?>" target="_blank" class="btn btn-xs btn-outline-success float-right"><i class="fas fa-file-excel"></i> INFORMES</a>
            <a href="<?php echo e(route('palletitems.excel', $load->id)); ?>" target="_blank" class="btn btn-xs btn-outline-success float-right"><i class="fas fa-file-excel"></i> PLANO DE CARGA</a>
            <hr>
            <?php if($palletsExist): ?>
               <div class="form-group">
                  <?php echo e(Form::model($palletsExist, ['route' => ['pallets.update', $palletsExist->id], 'class' => 'form-horizontal', 'method' => 'PUT'])); ?>

                     <div class="modal-body">
                        <div class="form-check">
                           <label class="form-check-label">
                              <?php echo Form::hidden('id_load', $load->id); ?>

                              <?php echo Form::hidden('id', $palletsExist->id); ?>

                              <?php echo Form::hidden('id_user', \Auth::user()->id); ?>

                              <?php echo Form::hidden('update_user', \Auth::user()->id); ?>

                              <input class="form-check-input" name="coordination" <?php echo e(($palletsExist2) ? 'checked' : ''); ?> type="checkbox">
                           Usar fincas y clientes coordinados</label>
                           <button type="submit" class="btn btn-outline-warning" data-toggle="tooltip" data-placement="top" title="Crear Empresa">
                              <i class="fas fa-sync"></i> Actualizar
                           </button>
                        </div>
                     </div>
                  <?php echo e(Form::close()); ?>

                  
               </div>
            <?php endif; ?>
            
               
               
                  
                  
                  
                  <?php $__currentLoopData = $pallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexKey =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="card">
                        <div class="card-header">
                           <i class="fas fa-pallet"></i> Paleta # <span class="badge bg-dark"><?php echo e($item->number); ?></span>
                           <input type="hidden" name="prueba" id="prueba_<?php echo e($indexKey); ?>" value="<?php echo e($item->number); ?>">
                           
                           <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'palletitems.create')): ?>
                           <button type="button" onclick="mifuncion(this)" value="<?php echo e($item->id); ?>" class="btn btn-xs btn-info float-right" data-toggle="modal" data-target="#addPalletItem_<?php echo e($item->id); ?>" data-toggle="tooltip" data-placement="top" title="Agregar item de paleta">
                              <i class="fas fa-plus-circle"></i>
                           </button>
                           <?php endif; ?>
                        </div>
                        <div class="card-body">
                           <div class="table-responsive">
                              <table class="table table-sm">
                                 <thead>
                                 <tr>
                                    <th class="text-center">Finca</th>
                                    <th class="text-center">Cliente</th>
                                    <th class="text-center">Piso</th>
                                    <th class="text-center">HB</th>
                                    <th class="text-center">QB</th>
                                    <th class="text-center">EB</th>
                                    <th class="text-center">Total</th>
                                    <th colspan="2" class="text-center">Aciones</th>
                                 </tr>
                                 </thead>
                                 <tbody>
                                    <?php
                                       $hb = 0; $qb = 0; $eb = 0; $total = 0;
                                    ?>
                                    <?php $__currentLoopData = $palletItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($item->id == $item2->id_pallet): ?>
                                          <?php 
                                             $hb+=$item2->hb;
                                             $qb+=$item2->qb;
                                             $eb+=$item2->eb;
                                             $total+=$item2->quantity;
                                          ?>
                                          <tr>
                                             <td>
                                                <?php $__currentLoopData = $farms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <?php if($item2->id_farm == $farm->id): ?>
                                                      <?php echo e(strtoupper(Str::limit(str_replace('SAG-', '', $farm->name), '20'))); ?>

                                                   <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             </td>
                                             <td class="text-center">
                                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <?php if($item2->id_client == $client->id): ?>
                                                      <?php echo e(strtoupper(Str::limit(str_replace('SAG-', '', $client->name), '8'))); ?>

                                                   <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             </td>
                                             <td class="text-center">
                                                <?php if($item2->piso == 1): ?>
                                                <span class="badge badge-warning">SI</span>
                                                <?php endif; ?>
                                             </td>
                                             <td class="text-center"><?php echo e($item2->hb); ?></td>
                                             <td class="text-center"><?php echo e($item2->qb); ?></td>
                                             <td class="text-center"><?php echo e($item2->eb); ?></td>
                                             <td class="text-center"><?php echo e($item2->quantity); ?></td>
                                             <td class="text-center" width="10px">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'palletitems.edit')): ?>
                                                <button type="button" onclick="mifuncion2(this)" value="<?php echo e($item2->id); ?>" class="btn btn-outline-warning btn-sm" data-toggle="modal" data-target="#editPalletItem<?php echo e($item2->id); ?>">
                                                   <i class="fas fa-pencil-alt"></i>
                                                </button>
                                                <?php endif; ?>
                                             </td>
                                             <td class="text-center" width="10px">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'palletitems.destroy')): ?>
                                                <?php echo Form::open(['route' => ['palletitems.destroy', $item2->id], 'method' => 'DELETE', 'onclick' => 'return confirm("¿Seguro de eliminar item de paleta?")']); ?>

                                                   <button class="btn btn-sm btn-outline-danger" data-toggle="tooltip" data-placement="top" title="Eliminar item de paleta"><i class="fas fa-trash-alt"></i></button>
                                                <?php echo Form::close(); ?>

                                                <?php endif; ?>
                                             </td>
                                          </tr>
                                          <div class="modal fade" id="editPalletItem<?php echo e($item2->id); ?>" tabindex="-1" aria-labelledby="editPalletItemLabel" aria-hidden="true">
                                             <div class="modal-dialog ">
                                                <div class="modal-content">
                                                   <div class="modal-header">
                                                      <h5 class="modal-title" id="editPalletItemLabel">Editar Pallet Items</h5>
                                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                         <span aria-hidden="true">&times;</span>
                                                      </button>
                                                   </div>
                                                   <div class="modal-body">
                                                      <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                                                      <?php echo e(Form::model($item2, ['route' => ['palletitems.update', $item2->id], 'class' => 'form-horizontal', 'method' => 'PUT'])); ?>

                                                         <div class="modal-body">
                                                            <?php echo $__env->make('palletitems.partials.formEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                         </div>
                                                         <div class="modal-footer">
                                                            <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cerrar</button>
                                                            <button type="submit" class="btn btn-outline-warning" data-toggle="tooltip" data-placement="top" title="Crear Empresa">
                                                               <i class="fas fa-sync"></i> Actualizar
                                                            </button>
                                                         </div>
                                                      <?php echo e(Form::close()); ?>

                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </tbody>
                                 <tfoot>
                                    <tr>
                                       <th colspan="3" class="text-center">Totales</th>
                                       <th class="text-center"><?php echo e($hb); ?></th>
                                       <th class="text-center"><?php echo e($qb); ?></th>
                                       <th class="text-center"><?php echo e($eb); ?></th>
                                       <th class="text-center"><?php echo e($total); ?></th>
                                    </tr>
                                </tfoot>
                              </table>
                           </div>
                           <?php if(($counter - 1) == $item->counter): ?>
                           <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'pallets.edit')): ?>
                              <button type="button" class="btn btn-xs btn-warning pull-right" data-toggle="modal" data-target="#editPallet" data-toggle="tooltip" data-placement="top" title="Editar nuevas paletas"><i class="fas fa-edit"></i> Editar</button>
                           <?php endif; ?>
                           <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'pallets.destroy')): ?>
                                 <?php echo Form::open(['route' => ['pallets.destroy', $item->id], 'method' => 'DELETE']); ?>

                                    <?php echo Form::button('<i class="fas fa-trash-alt"></i> ' . 'Eliminar', ['type' => 'submit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'title' => 'Eliminar paleta', 'class' => 'btn btn-xs btn-danger pull-right', 'onclick' => 'return confirm("¿Seguro de eliminar finca?")']); ?>

                                 <?php echo Form::close(); ?>

                           <?php endif; ?>
                                 
                                 <!-- Modal Edit Pallet -->
                                 <div class="modal fade" id="editPallet" tabindex="-1" role="dialog" aria-labelledby="editPalletLabel">
                                    <div class="modal-dialog" role="document">
                                       <div class="modal-content">
                                             <div class="modal-header">
                                                <h5 class="modal-title" id="agregarItemLabel">Contenedor <?php echo e($load->shipment); ?></h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                   <span aria-hidden="true">&times;</span>
                                                </button>
                                             </div>
                                          <div class="modal-body">
                                                <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php echo e(Form::model($item, ['route' => ['pallets.update', $item->id], 'class' => 'form-horizontal', 'method' => 'PUT'])); ?>

                                                   <div class="modal-body">
                                                      <?php echo $__env->make('pallets.partials.formEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                   </div>
                                                   <div class="modal-footer">
                                                      <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cerrar</button>
                                                      <button type="submit" class="btn btn-outline-warning" data-toggle="tooltip" data-placement="top" title="Crear Empresa">
                                                         <i class="fas fa-sync"></i> Actualizar
                                                      </button>
                                                   </div>
                                                <?php echo e(Form::close()); ?>

                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- /Modal Edit Pallet -->
                              
                           <?php endif; ?>
                        </div>
                     </div>

                     <!-- Modal Pallets Items -->
                     <div class="modal fade" id="addPalletItem_<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="addPalletItemLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                 <div class="modal-header">
                                    <h5 class="modal-title" id="agregarItemLabel">Paleta <?php echo e($item->number); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                    </button>
                                 </div>
                                <div class="modal-body">
                                    <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     
                                    <?php echo e(Form::open(['route' => 'palletitems.store', 'class' => 'form-horizontal'])); ?>

                                        <?php echo Form::hidden('id_user', \Auth::user()->id); ?>

                                        <?php echo Form::hidden('update_user', \Auth::user()->id); ?>

                                        <?php echo Form::hidden('id_load', $load->id); ?>

                                       <input type="hidden" name="id_pallet" id="id_pallet" value="<?php echo e($item->id); ?>" class="grupo">

                                        <?php echo $__env->make('palletitems.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="form-group">
                                            <div class="col-sm-offset-2 col-sm-10">
                                                <button type="submit" class="btn btn-xs btn-primary"><i class="fas fa-plus-circle"></i> Agregar</button>
                                            </div>
                                        </div>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            </div>
                        </div>
                     </div>
                    
                    <!-- End Modal Pallets Items -->
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
               
             
             <button class="btn btn-default  " type="button">
               HB <span class="badge"><?php echo e($total_hb); ?></span>
            </button>
            <button class="btn btn-primary" type="button">
               QB <span class="badge"><?php echo e($total_qb); ?></span>
            </button>
            <button class="btn btn-info" type="button">
               EB <span class="badge"><?php echo e($total_eb); ?></span>
            </button>
            <button class="btn btn-success" type="button">
               Total <span class="badge"><?php echo e($total_container); ?></span>
            </button>
            </div>
            <div class="col-sm">
             <div class="card text-white bg-dark">
               <div class="card-header">
                 Resumen de la carga - #<?php echo e($load->shipment); ?>

                 <a href="<?php echo e(route('palletitems.pdf', $load)); ?>" target="_blank" class="btn btn-xs btn-outline-success pull-right"><i class="far fa-file-pdf"></i> Cierre PDF</a>
                 <a href="<?php echo e(route('closing.excel', $load)); ?>" target="_blank" class="btn btn-xs btn-outline-primary pull-right"><i class="far fa-file-excel"></i> Cierre Excel</a>
               </div>
               <div class="card-body">
                  <!-- tabla de coordinaciones -->
                  <div class="table-responsive">
                     <table class="table table-sm">
                         <?php
                             $totalFulls = 0; $totalHb = 0; $totalQb = 0; $totalEb = 0; $totalPcsr = 0; $totalHbr = 0; $totalQbr = 0;
                             $totalEbr = 0; $totalFullsr = 0; $totalDevr = 0; $totalMissingr = 0; $totalPieces = 0;
                         ?>
                         <?php $__currentLoopData = $resumenCargaAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <thead>
                             <tr>
                                 <th colspan="15" class="sin-border"></th>
                             </tr>
                         </thead>
                         <thead>
                             <tr>
                                 <th class="text-center medium-letter" colspan="5"><?php echo e($client['name']); ?></th>
                             </tr>
                         </thead>
                         <thead>
                             <tr class="gris">
                               <th class="text-center">Fincas</th>
                               <th class="text-center">PCS</th>
                               <th class="text-center">HB</th>
                               <th class="text-center">QB</th>
                               <th class="text-center">EB</th>
                             </tr>
                         </thead>
                         <tbody>
                             <?php
                                 $tPieces = 0; $tHb = 0; $tQb = 0; $tEb = 0; 
                             ?>
                             <?php $__currentLoopData = $itemsCarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php if($client['id'] == $item['id_client']): ?>
                             <?php
                                 $tPieces+= $item['quantity'];
                                 $tHb+= $item['hb'];
                                 $tQb+= $item['qb'];
                                 $tEb+= $item['eb'];
                             ?>
                             <tr>
                                 <td class="farms"><?php echo e($item['farms']); ?></td>
                                 <td class="text-center"><?php echo e($item['quantity']); ?></td>
                                 <td class="text-center"><?php echo e($item['hb']); ?></td>
                                 <td class="text-center"><?php echo e($item['qb']); ?></td>
                                 <td class="text-center"><?php echo e($item['eb']); ?></td>
                             </tr>
                             
                             <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php
                                  $totalHb+= $tHb;
                                  $totalQb+= $tQb;
                                  $totalEb+= $tEb;
                               ?>
                            <tr class="gris">
                               <th class="text-center text-right">Total:</th>
                               <th class="text-center"><?php echo e($tPieces); ?></th>
                               <th class="text-center"><?php echo e($tHb); ?></th>
                               <th class="text-center"><?php echo e($tQb); ?></th>
                               <th class="text-center"><?php echo e($tEb); ?></th>
                            </tr>
                         </tbody>
                         <tfoot>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php
                             $totalPieces+= $totalHb + $totalQb + $totalEb;
                         ?>
                             <tr>
                                 <th colspan="8" class="sin-border"></th>
                             </tr>
                             <tr class="gris">
                                 <th class="text-center">Total Global:</th>
                                 <th class="text-center"><?php echo e($totalPieces); ?></th>
                                 <th class="text-center"><?php echo e($totalHb); ?></th>
                                 <th class="text-center"><?php echo e($totalQb); ?></th>
                                 <th class="text-center"><?php echo e($totalEb); ?></th>
                             </tr>
                         </tfoot>
                     </table>
                   </div>
                   <!-- fin tabla de coordinaciones -->
               </div>
             </div>
            </div>
         
      </div>
   </div>
</section>
<!-- Modal Create Pallets -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
   <div class="modal-dialog" role="document">
       <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="agregarItemLabel">Contenedor <?php echo e($load->shipment); ?></h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
               </button>
            </div>
           <div class="modal-body">
               <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

               <?php echo e(Form::open(['route' => 'pallets.store', 'class' => 'form-horizontal'])); ?>

                  <div class="modal-body">
                     <?php echo $__env->make('pallets.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <div class="modal-footer">
                     <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cerrar</button>
                     <button type="submit" class="btn btn-outline-primary" data-toggle="tooltip" data-placement="top" title="Crear Empresa">
                        <i class="fas fa-plus-circle"></i> Crear
                     </button>
                  </div>
               <?php echo e(Form::close()); ?>

           </div>
       </div>
   </div>
</div>
<!-- /Modal Create Pallets -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

function mifuncion(elemento) {
    var id_pallet = elemento.getAttribute('value');
    $(document).ready(function(){
        //alert(id_pallet);
        $(".grupo").keyup(function()
        {
            var hb = $('#hb_'+id_pallet).val();
            var qb = $('#qb_'+id_pallet).val();
            var eb = $('#eb_'+id_pallet).val();
            var total = parseFloat(hb) + parseFloat(qb) + parseFloat(eb);
            $('#total_'+id_pallet).val(parseFloat(total));
            console.log(total);
        });

        $('#farmsList_'+id_pallet).select2({
            theme: 'bootstrap4',
        });
        $('#clientsList_'+id_pallet).select2({
            theme: 'bootstrap4',
        });
    });
}

function mifuncion2(elemento) {
    var id_pallet = elemento.getAttribute('value');
    $(document).ready(function(){
        //alert(id_pallet);
        $(".grupo").keyup(function()
        {
            var hb = $('#edit_hb_'+id_pallet).val();
            var qb = $('#edit_qb_'+id_pallet).val();
            var eb = $('#edit_eb_'+id_pallet).val();
            var total = parseFloat(hb) + parseFloat(qb) + parseFloat(eb);
            $('#edit_total_'+id_pallet).val(parseFloat(total));
            console.log(total);
        });
        $('#edit_farmsList_'+id_pallet).select2({
            theme: 'bootstrap4',
        });
        $('#edit_clientsList_'+id_pallet).select2({
            theme: 'bootstrap4',
        });
        
    });
    
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/pallets/index.blade.php ENDPATH**/ ?>