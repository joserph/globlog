<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'logistic.create')): ?>
<h2>Crear Empresa de logística</h2>
<?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php echo $__env->make('logistic.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<button wire:click="store" class="btn btn-outline-primary" id="createLogistic" data-toggle="tooltip" data-placement="top" title="Crear Empresa">
    <i class="fas fa-plus-circle"></i> Crear
</button>
<?php endif; ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/logistic/create.blade.php ENDPATH**/ ?>