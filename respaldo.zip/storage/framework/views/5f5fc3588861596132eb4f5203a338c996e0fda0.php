

<?php $__env->startSection('title'); ?> Coordinaciones Aéreas | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="container-fluid">
       <div class="row mb-2">
          <div class="col-sm-6">
             <h1>Coordinaciones Aéreas</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item"><a href="<?php echo e(route('flight.index')); ?>">Vuelos</a></li>
               <li class="breadcrumb-item"><a href="<?php echo e(route('flight.show', $flight->id)); ?>">AWB <?php echo e($flight->awb); ?></a></li>
               <li class="breadcrumb-item active">Coordinaciones Aéreas</li>
            </ol>
          </div>
       </div>
    </div><!-- /.container-fluid -->
 </section>


  <!-- Main content -->
<section class="content">
   <div class="container-fluid">
      <div class="row justify-content-center">
         <div class="col-12">

            <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

            <div class="card">
               <div class="card-header">
                  Coordinaciones Vuelo AWB <?php echo e($flight->awb); ?>

               </div>
               <div class="card-body">
                     <div class="row">
                        <div class="col-sm-6">
                          <div class="card">
                            <div class="card-body">
                              <h5 class="card-title">AWB <?php echo e($flight->awb); ?></h5>
                              <p class="card-text"><?php echo e(date('d/m/Y', strtotime($flight->date))); ?></p>
                              <p class="card-text"><?php echo e($company->name); ?></p>
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'distribution.create')): ?>
                              <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#agregarItem">
                                 <i class="fas fa-plus-circle"></i> Crear Item
                              </button>
                              <?php endif; ?>
                            </div>
                          </div>
                          <a href="<?php echo e(route('distribution.pdf', $flight)); ?>" target="_blank" class="btn btn-xs btn-outline-success pull-right"><i class="far fa-file-pdf"></i> COMPLETO</a>
                          <a href="<?php echo e(route('distributionUncoordinated.pdf', $flight)); ?>" target="_blank" class="btn btn-xs btn-outline-info pull-right"><i class="far fa-file-pdf"></i> SOLO RECIBIDO</a>
                          <a href="<?php echo e(route('distributionForDelivery.pdf', $flight)); ?>" target="_blank" class="btn btn-xs btn-outline-primary pull-right"><i class="far fa-file-pdf"></i> PARA DELIVERY</a>
                          <a href="<?php echo e(route('distribution.excel', $flight)); ?>" target="_blank" class="btn btn-xs btn-outline-success pull-right"><i class="fas fa-file-excel"></i></a>
                          <!--
                          <div class="form-group col-md-12">
                              <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success">
                              <input type="checkbox" class="custom-control-input" id="switchCoord">
                              <label class="custom-control-label" for="switchCoord">Transferir coordinación</label>
                              </div>
                           </div>
                           <a href="#" id="ListCoord" class="btn btn-xs btn-outline-success pull-right"><i class="fas fa-exchange-alt"></i></a>

                           <div class="row listaSelect">
                              <div class="card">
                                 <div class="card-body">
                                    <h3>Fincas seleccionadas</h3>
                                    <br>

                                    <ul id="lista" class="list-group"></ul>
                                 </div>
                                 <div class="card-footer">
                                    <a href="<?php echo e(route('transfer-coordination', $flight)); ?>" value="Hola" id="btnTransf" class="btn btn-xs btn-outline-info pull-right"><i class="fas fa-exchange-alt"></i> Transferir</a>
                                 </div>
                              </div>
                           </div>
                        -->
                        </div>
                        <div class="col-sm-6">
                          <div class="card">
                            <div class="card-body">
                              <h5 class="card-title">Resumen coordinación</h5>
                              <table class="table table-hover table-sm">
                                 <?php
                                     $totalFulls = 0; $totalHb = 0; $totalQb = 0; $totalEb = 0; $totalPieces = 0;
                                 ?>
                                 <thead>
                                    <tr class="gris">
                                        <th>Cliente</th>
                                        <th class="text-center">PCS</th>
                                        <th class="text-center">HB</th>
                                        <th class="text-center">QB</th>
                                        <th class="text-center">EB</th>
                                    </tr>
                                </thead>
                                 <?php $__currentLoopData = $clientsDistribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 
                                 <tbody>
                                     <?php
                                         $tPieces = 0; $tFulls = 0; $tHb = 0; $tQb = 0; $tEb = 0;
                                     ?>
                                     <?php $__currentLoopData = $distributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($client['id'] == $item->id_client): ?>
                                       <?php
                                          $tPieces+= $item->pieces;
                                          $tFulls+= $item->fulls;
                                          $tHb+= $item->hb;
                                          $tQb+= $item->qb;
                                          $tEb+= $item->eb;
                                       ?>
                                       
                                       <?php endif; ?>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <?php
                                       $totalFulls+= $tFulls;
                                       $totalHb+= $tHb;
                                       $totalQb+= $tQb;
                                       $totalEb+= $tEb;
                                    ?>
                                    <tr>
                                       <td><?php echo e($client['name']); ?></td>
                                       <td class="text-center"><?php echo e($tPieces); ?></td>
                                       <td class="text-center"><?php echo e($tHb); ?></td>
                                       <td class="text-center"><?php echo e($tQb); ?></td>
                                       <td class="text-center"><?php echo e($tEb); ?></td>
                                   </tr>
                                 </tbody>
                                 <tfoot>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php
                                     $totalPieces+= $totalHb + $totalQb + $totalEb;
                                 ?>
                                     <tr>
                                         <th>Total Global:</th>
                                         <th class="text-center"><?php echo e($totalPieces); ?></th>
                                         <th class="text-center"><?php echo e($totalHb); ?></th>
                                         <th class="text-center"><?php echo e($totalQb); ?></th>
                                         <th class="text-center"><?php echo e($totalEb); ?></th>
                                     </tr>
                                 </tfoot>
                             </table>
                            </div>
                          </div>
                          
                        </div>
                      </div>
                  
               </div>
               <div class="card-footer">
                  <!-- tabla de coordinaciones -->
                  <div class="table-responsive">
                    <table class="table table-sm table-bordered border-primary">
                        <?php
                            $totalFulls = 0; $totalHb = 0; $totalQb = 0; $totalEb = 0; $totalPcsr = 0; $totalHbr = 0; $totalQbr = 0;
                            $totalEbr = 0; $totalFullsr = 0; $totalDevr = 0; $totalMissingr = 0;
                        ?>
                        <?php $__currentLoopData = $clientsDistribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <thead>
                            <tr>
                                <th colspan="18" class="sin-border"></th>
                            </tr>
                        </thead>
                        <thead>
                            <tr>
                                <th class="text-center medium-letter">AWB</th>
                                <th class="text-center medium-letter" colspan="17"><?php echo e($client['name']); ?></th>
                            </tr>
                        </thead>
                        <thead>
                            <tr class="gris">
                              <th class="text-center transfLavel">Transferir</th>
                              <th class="text-center">Finca</th>
                              <th class="text-center">HAWB</th>
                              <th class="text-center">Variedad</th>
                              <th class="text-center table-secondary">PCS</th>
                              <th class="text-center table-secondary">HB</th>
                              <th class="text-center table-secondary">QB</th>
                              <th class="text-center table-secondary">EB</th>
                              <th class="text-center table-secondary">FULL</th>
                              <th class="text-center table-success">PCS</th>
                              <th class="text-center table-success">HB</th>
                              <th class="text-center table-success">QB</th>
                              <th class="text-center table-success">EB</th>
                              <th class="text-center table-success">FULL</th>
                              <th class="text-center table-warning">Dev</th>
                              <th class="text-center">Faltantes</th>
                              <th class="text-center">Observación</th>
                              <th class="text-center" colspan="2">Aciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $tPieces = 0; $tFulls = 0; $tHb = 0; $tQb = 0; $tEb = 0; $totalPieces = 0; $tPcsR = 0;
                                 $tHbr = 0; $tQbr = 0; $tEbr = 0; $tFullsR = 0; $tDevR = 0; $tMissingR = 0;
                            ?>
                            
                            <?php $__currentLoopData = $distributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($client['id'] == $item->id_client): ?>
                            <?php
                                $tPieces+= $item->pieces;
                                $tFulls+= $item->fulls;
                                $tHb+= $item->hb;
                                $tQb+= $item->qb;
                                $tEb+= $item->eb;
                                $tPcsR+= $item->pieces_r;
                                 $tHbr+= $item->hb_r;
                                 $tQbr+= $item->qb_r;
                                 $tEbr+= $item->eb_r;
                                 $tFullsR+= $item->fulls_r;
                                 $tDevR+= $item->returns;
                                 $tMissingR+= $item->missing;
                            ?>
                            <tr>
                               <!--<td class="text-center"><input type="checkbox" class="transf" name="<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>" placeholder="<?php echo e($item->name); ?> - <?php echo e($client['name']); ?> - <?php echo e($item->pieces); ?>"></td>-->
                                <td class="farms"><?php echo e($item->name); ?></td>
                                <td class="text-center"><?php echo e($item->hawb); ?></td>
                                <td class="text-center"><?php echo e($item->variety->name); ?></td>
                                <td class="text-center"><?php echo e($item->pieces); ?></td>
                                <td class="text-center"><?php echo e($item->hb); ?></td>
                                <td class="text-center"><?php echo e($item->qb); ?></td>
                                <td class="text-center"><?php echo e($item->eb); ?></td>
                                <td class="text-center"><?php echo e(number_format($item->fulls, 3, '.','')); ?></td>
                                <td class="text-center"><?php echo e($item->pieces_r); ?></td>
                                <td class="text-center"><?php echo e($item->hb_r); ?></td>
                                <td class="text-center"><?php echo e($item->qb_r); ?></td>
                                <td class="text-center"><?php echo e($item->eb_r); ?></td>
                                <td class="text-center"><?php echo e(number_format($item->fulls_r, 3, '.','')); ?></td>
                                <td class="text-center"><?php echo e($item->returns); ?></td>
                                <td class="text-center"><?php echo e($item->missing); ?></td>
                                <td class="text-center text-danger"><small>
                                    <?php if($item->id_marketer): ?>
                                       COMPRA DE <?php echo e(strtoupper($item->marketer->name)); ?> 
                                    <?php endif; ?>
                                    <?php echo e(strtoupper($item->observation)); ?>

                                 </small></td>
                                <td class="text-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'distribution.edit')): ?>
                                    <button type="button" class="btn btn-outline-warning btn-sm" data-toggle="modal" data-target="#editarItem<?php echo e($item->id); ?>">
                                       <i class="fas fa-pencil-alt"></i>
                                    </button>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'distribution.destroy')): ?>
                                    <td width="20px" class="text-center">
                                       <?php echo e(Form::open(['route' => ['distribution.destroy', $item->id], 'method' => 'DELETE'])); ?>

                                          <?php echo e(Form::button('<i class="fas fa-trash-alt"></i> ', ['type' => 'submit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'title' => 'Eliminar usuario', 'class' => 'btn btn-sm btn-outline-danger', 'onclick' => 'return confirm("¿Seguro de eliminar la coordinación?")'])); ?>

                                       <?php echo e(Form::close()); ?>

                                    </td>
                                    <?php endif; ?>
                               </td>
                            </tr>
                            <div class="modal fade" id="editarItem<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="editarItemLabel" aria-hidden="true">
                              <div class="modal-dialog modal-xl">
                                 <div class="modal-content">
                                    <div class="modal-header">
                                       <h5 class="modal-title" id="editarItemLabel">Editar item de coordinación</h5>
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                       </button>
                                    </div>
                                    <div class="modal-body">
                                       <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                                       <?php echo e(Form::model($item, ['route' => ['distribution.update', $item->id], 'class' => 'form-horizontal', 'method' => 'PUT'])); ?>

                                          <div class="modal-body">
                                             <?php echo $__env->make('distribution.partials.formEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                          </div>
                                          <div class="modal-footer">
                                             <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cerrar</button>
                                             <button type="submit" class="btn btn-outline-warning" data-toggle="tooltip" data-placement="top" title="Crear Empresa">
                                                <i class="fas fa-sync"></i> Actualizar
                                             </button>
                                          </div>
                                       <?php echo e(Form::close()); ?>

                                    </div>
                                 </div>
                              </div>
                           </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php
                                 $totalFulls+= $tFulls;
                                 $totalHb+= $tHb;
                                 $totalQb+= $tQb;
                                 $totalEb+= $tEb;
                                 $totalPcsr+= $tPcsR;
                                 $totalHbr+= $tHbr;
                                 $totalQbr+= $tQbr;
                                 $totalEbr+= $tEbr;
                                 $totalFullsr+= $tFullsR;
                                 $totalDevr+= $tDevR;
                                 $totalMissingr+= $tMissingR;
                              ?>
                           <tr class="gris">
                              <th class="text-center text-right" colspan="3">Total:</th>
                              <th class="text-center"><?php echo e($tPieces); ?></th>
                              <th class="text-center"><?php echo e($tHb); ?></th>
                              <th class="text-center"><?php echo e($tQb); ?></th>
                              <th class="text-center"><?php echo e($tEb); ?></th>
                              <th class="text-center"><?php echo e(number_format($tFulls, 3, '.','')); ?></th>
                              <th class="text-center"><?php echo e($tPcsR); ?></th>
                              <th class="text-center"><?php echo e($tHbr); ?></th>
                              <th class="text-center"><?php echo e($tQbr); ?></th>
                              <th class="text-center"><?php echo e($tEbr); ?></th>
                              <th class="text-center"><?php echo e(number_format($tFullsR, 3, '.','')); ?></th>
                              <th class="text-center"><?php echo e($tDevR); ?></th>
                              <th class="text-center"><?php echo e($tMissingR); ?></th>
                           </tr>
                        </tbody>
                        <tfoot>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $totalPieces+= $totalHb + $totalQb + $totalEb;
                        ?>
                            <tr>
                                <th colspan="8" class="sin-border"></th>
                            </tr>
                            <tr class="gris">
                                <th class="text-center" colspan="3">Total Global:</th>
                                <th class="text-center"><?php echo e($totalPieces); ?></th>
                                <th class="text-center"><?php echo e($totalHb); ?></th>
                                <th class="text-center"><?php echo e($totalQb); ?></th>
                                <th class="text-center"><?php echo e($totalEb); ?></th>
                                <th class="text-center"><?php echo e(number_format($totalFulls, 3, '.','')); ?></th>
                                <th class="text-center"><?php echo e($totalPcsr); ?></th>
                                <th class="text-center"><?php echo e($totalHbr); ?></th>
                                <th class="text-center"><?php echo e($totalQbr); ?></th>
                                <th class="text-center"><?php echo e($totalEbr); ?></th>
                                <th class="text-center"><?php echo e(number_format($totalFullsr, 3, '.','')); ?></th>
                                <th class="text-center"><?php echo e($totalDevr); ?></th>
                                <th class="text-center"><?php echo e($totalMissingr); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                  </div>
                  <!-- fin tabla de coordinaciones -->
               </div>
            </div>
            
         </div>
         
         <div class="modal fade" id="agregarItem" tabindex="-1" aria-labelledby="agregarItemLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
               <div class="modal-content">
                  <div class="modal-header">
                     <h5 class="modal-title" id="agregarItemLabel">Agregar item de coordinación</h5>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                     </button>
                  </div>
                  <div class="modal-body">
                     <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     <?php echo e(Form::open(['route' => 'distribution.store', 'class' => 'form-horizontal'])); ?>

                        <div class="modal-body">
                           <?php echo $__env->make('distribution.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="modal-footer">
                           <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cerrar</button>
                           <button type="submit" class="btn btn-outline-primary" data-toggle="tooltip" data-placement="top" title="Crear Empresa">
                              <i class="fas fa-plus-circle"></i> Crear
                           </button>
                        </div>
                     <?php echo e(Form::close()); ?>

                  </div>
               </div>
            </div>
         </div>
         

         


      </div>
   </div>
</section>

<?php $__env->startSection('scripts'); ?>
   <script>
      $('#id_farmEdit').select2({
         theme: 'bootstrap4',
      });

      $('#id_farm').select2({
         theme: 'bootstrap4',
      });
      $('#id_client').select2({
         theme: 'bootstrap4'
      });
      $('#variety_id').select2({
         theme: 'bootstrap4'
      });

      $(document).ready(function()
      {
         $('#transfCoord').hide();
         $('.transfLavel').hide();
         $('.transf').hide();
         $('#btnTransf').hide();
         $('#switchCoord').on('change', function() {
            if ($(this).is(':checked') ) {
               $('#transfCoord').show();
               $('#transfLavel').show();
               $('.transf').show();
            } else {
               $('#transfCoord').hide();
               $('#transfLavel').hide();
               $('.transf').hide();
            }
         });
      });

      // listar fincas selecionadas
      var lista = document.getElementById('lista');
      var checks_farm = document.querySelectorAll('.transf');
      var test = [];

      $('#ListCoord').click(function()
      {
         
         lista.innerHTML = '';
         checks_farm.forEach((e)=>{
            if(e.checked == true)
            {
               var elemento = document.createElement('li');
               elemento.className = 'list-group-item';
               elemento.innerHTML = e.placeholder;
               test.push(e.value)
               lista.appendChild(elemento);
               $('#btnTransf').show();
            }
            
         });
         /*$('#btnTransf').click(function()
         {
            $.ajax({
               url: "transfer-coordination",
               type: "POST",
               data: test,
               success: function(response)
               {
                  if(response)
                  {
                     $('#transfCoord').hide();
                     $('#transfLavel').hide();
                     $('.transf').hide();
                     $('#btnTransf').hide();
                     toastr.success('Transferencia exitosa');
                  }
               }
            });
         });*/
         
         for ( x in test) {
            console.log( test[x] );
         }
      });

      
   </script>

   
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/distribution/index.blade.php ENDPATH**/ ?>