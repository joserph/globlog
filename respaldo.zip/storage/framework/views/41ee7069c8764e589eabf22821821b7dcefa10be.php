

<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6">
               <h1 class="m-0">Panel Principal</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                  <li class="breadcrumb-item active">Panel Principal v1</li>
               </ol>
            </div><!-- /.col -->
         </div><!-- /.row -->
      </div><!-- /.container-fluid -->
   </div>
   <div class="row">
      <div class="col-lg-3 col-6">
         <!-- small box -->
         <div class="small-box bg-info">
            <div class="inner">
               <h3><?php echo e($farms); ?></h3>
               <p>Fincas Agregadas</p>
            </div>
            <div class="icon">
               <i class="nav-icon fas fa-spa"></i>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'farms')): ?>
               <a href="<?php echo e(url('farms')); ?>" class="small-box-footer">Ver <i class="fas fa-arrow-circle-right"></i></a>
            <?php endif; ?>
         </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
         <!-- small box -->
         <div class="small-box bg-success">
            <div class="inner">
               <h3><?php echo e($clients); ?></h3>
               <p>Clientes</p>
            </div>
            <div class="icon">
               <i class="nav-icon fas fa-user-tie"></i>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'clients')): ?>
               <a href="<?php echo e(url('clients')); ?>" class="small-box-footer">Ver <i class="fas fa-arrow-circle-right"></i></a>
            <?php endif; ?>
         </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
         <!-- small box -->
         <div class="small-box bg-warning">
            <div class="inner">
               <h3><?php echo e($varieties); ?></h3>
               <p>Variedades</p>
            </div>
            <div class="icon">
               <i class="nav-icon fas fa-fan"></i>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'varieties')): ?>
               <a href="<?php echo e(url('varieties')); ?>" class="small-box-footer">Ver <i class="fas fa-arrow-circle-right"></i></a>
            <?php endif; ?>
         </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
         <!-- small box -->
         <div class="small-box bg-danger">
            <div class="inner">
               <h3><?php echo e($loads); ?></h3>
               <p>Contenedores</p>
            </div>
            <div class="icon">
               <i class="nav-icon fas fa-truck-loading"></i>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'load.index')): ?>
               <a href="<?php echo e(route('load.index')); ?>" class="small-box-footer">Ver <i class="fas fa-arrow-circle-right"></i></a>
            <?php endif; ?>
         </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
         <!-- small box -->
         <div class="small-box bg-primary">
            <div class="inner">
               <h3><?php echo e($flights); ?></h3>
               <p>Vuelos</p>
            </div>
            <div class="icon">
               <i class="nav-icon fas fa-plane"></i>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'flight.index')): ?>
               <a href="<?php echo e(route('flight.index')); ?>" class="small-box-footer">Ver <i class="fas fa-arrow-circle-right"></i></a>
            <?php endif; ?>
         </div>
      </div>
      <div class="col-lg-3 col-6">
         <div class="small-box bg-info">
            <div class="inner">
               <h3><?php echo e($company); ?></h3>
               <p><?php echo e(Str::title(Str::limit($companyName[0]->name, '16'))); ?></p>
            </div>
            <div class="icon">
               <i class="nav-icon fas fa-building"></i>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'companies')): ?>
               <a href="<?php echo e(url('companies')); ?>" class="small-box-footer">Ver <i class="fas fa-arrow-circle-right"></i></a>
            <?php endif; ?>
         </div>
      </div>
      <div class="col-lg-3 col-6">
         <div class="small-box bg-success">
            <div class="inner">
               <h3><?php echo e($logisticCompany); ?></h3>
               <p><?php echo e(Str::title(Str::limit($logisticCompanyName[0]->name, '18'))); ?></p>
            </div>
            <div class="icon">
               <i class="nav-icon fas fa-warehouse"></i>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'logistics')): ?>
               <a href="<?php echo e(url('logistics')); ?>" class="small-box-footer">Ver <i class="fas fa-arrow-circle-right"></i></a>
            <?php endif; ?>
         </div>
      </div>
      <div class="col-lg-3 col-6">
         <div class="small-box bg-warning">
            <div class="inner">
               <h3><?php echo e($colors); ?></h3>
               <p>Colores</p>
            </div>
            <div class="icon">
               <i class="nav-icon fas fa-palette"></i>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'color.index')): ?>
               <a href="<?php echo e(route('color.index')); ?>" class="small-box-footer">Ver <i class="fas fa-arrow-circle-right"></i></a>
            <?php endif; ?>
         </div>
      </div>
      <div class="col-lg-3 col-6">
         <div class="small-box bg-danger">
            <div class="inner">
               <h3><?php echo e($marketers); ?></h3>
               <p>Comercializadoras</p>
            </div>
            <div class="icon">
               <i class="fas fa-hand-holding-usd"></i>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'marketer.index')): ?>
               <a href="<?php echo e(route('marketer.index')); ?>" class="small-box-footer">Ver <i class="fas fa-arrow-circle-right"></i></a>
            <?php endif; ?>
         </div>
      </div>




   </div><!-- /end row -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/home.blade.php ENDPATH**/ ?>