<div class="row">
    <div class="col-sm-2">
        <?php echo e(Form::label('report_w', 'Reported Weight', ['class' => 'control-label'])); ?>

        <?php echo e(Form::text('report_w', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('large', 'Largo', ['class' => 'control-label'])); ?>

        <?php echo e(Form::text('large', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('width', 'Ancho', ['class' => 'control-label'])); ?>

        <?php echo e(Form::text('width', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('high', 'Alto', ['class' => 'control-label'])); ?>

        <?php echo e(Form::text('high', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="col-sm-4">
        <?php echo e(Form::label('observation', 'Observación', ['class' => 'control-label'])); ?>

        <?php echo e(Form::select('observation', $packings, null, ['class' => 'form-control', 'placeholder' => 'Seleccione Observación'])); ?>

    </div>

    <?php echo e(Form::hidden('update_user', Auth::user()->id, ['id' => 'update_user'])); ?>

    <?php echo e(Form::hidden('id_flight', $flight->id, ['id' => 'id_flight'])); ?>

    <?php echo e(Form::hidden('id_distribution', $item['id'], ['id' => 'id_distribution'])); ?>

    
</div>

<?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/weightdistribution/partials/formEdit.blade.php ENDPATH**/ ?>