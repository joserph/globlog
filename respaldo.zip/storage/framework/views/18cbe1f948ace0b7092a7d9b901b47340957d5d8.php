<div class="form-group row">
    <?php echo e(Form::label('name', 'Nombre', ['class' => 'col-sm-2 control-label'])); ?>

    <div class="col-sm-10">
        <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

    </div>
</div>
<div class="form-group row">
    <?php echo e(Form::label('slug', 'Slug', ['class' => 'col-sm-2 control-label'])); ?>

    <div class="col-sm-10">
        <?php echo e(Form::text('slug', null, ['class' => 'form-control'])); ?>

    </div>
</div>
<div class="form-group row">
    <?php echo e(Form::label('description', 'Descricción', ['class' => 'col-sm-2 control-label'])); ?>

    <div class="col-sm-10">
        <?php echo e(Form::textarea('description', null, ['class' => 'form-control'])); ?>

    </div>
</div>
<hr>
<h3>Full Acceso</h3>
<div class="form-group">
    <label><?php echo e(Form::radio('full_access', 'yes')); ?> Si</label>
    <label><?php echo e(Form::radio('full_access', 'no', true)); ?> No</label>
</div>

<h3>Lista de Permisos</h3>
<div class="form-group">
    
    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-check">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <input class="form-check-input" type="checkbox" value="<?php echo e($permission->id); ?>" id="permission_<?php echo e($permission->id); ?>" name="permission[]" 
        
        <?php if(is_array(old('permission')) && in_array("$permission->id", old('permission'))): ?> checked 
        <?php endif; ?>
        >
        <label class="form-check-label" for="permission_<?php echo e($permission->id); ?>">
            <?php echo e($permission->id); ?> - <?php echo e($permission->name); ?> <em><?php echo e($permission->description); ?></em>
        </label>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH C:\laragon\www\app-ffc\resources\views/role/partials/form.blade.php ENDPATH**/ ?>