<div class="form-group row">
    <?php echo e(Form::label('name', 'Nombre', ['class' => 'col-sm-2 control-label'])); ?>

    <div class="col-sm-10">
        <?php echo e(Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Nombre'])); ?>

    </div>
</div>

<div class="form-group row">
    <?php echo e(Form::label('email', 'Correo', ['class' => 'col-sm-2 control-label'])); ?>

    <div class="col-sm-10">
        <?php echo e(Form::text('email', null, ['class' => 'form-control', 'placeholder' => 'Correo', 'readonly'])); ?>

    </div>
</div>

<?php echo e(Form::hidden('roles', $user->roles[0]->id)); ?>

<?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/user/partials/formP.blade.php ENDPATH**/ ?>