<div class="row">
   <?php echo Form::hidden('id_user', \Auth::user()->id); ?>

   <?php echo Form::hidden('update_user', \Auth::user()->id); ?>

   <?php echo Form::hidden('id_load', $load->id); ?>


   <div class="col-md-4 form-group">
      <?php echo e(Form::label('number', 'Número', ['class' => 'control-label'])); ?>

      <div class="input-group mb-3">
         <span class="input-group-text" id="basic-addon1"><?php echo e($load->shipment); ?> -</span>
         <?php echo e(Form::number('number1', $counter, ['class' => 'form-control', 'readonly'])); ?>

         <?php echo Form::hidden('counter', $counter); ?>

         <?php echo Form::hidden('number', $load->shipment); ?>

      </div>
   </div>
   <div class="col-md-12 form-group">
      <?php echo e(Form::label('usda', 'USDA', ['class' => 'control-label'])); ?>

      <div class="col-sm-2">
         <?php echo e(Form::checkbox('usda', null, false)); ?>

      </div>
   </div>
</div>
                            
                 <?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/pallets/partials/form.blade.php ENDPATH**/ ?>