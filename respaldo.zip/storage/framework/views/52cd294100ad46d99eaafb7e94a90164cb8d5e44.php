<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'logistic.index')): ?>
<h2>Empresas de logística</h2>
<div class="table-responsive">
   <table class="table table-sm table-hover">
    <thead>
       <tr>
          <th scope="col">Nombre</th>
          <th scope="col">Teléfono</th>
          <th scope="col">Dirección</th>
          <th scope="col">Estado</th>
          <th scope="col">Ciudad</th>
          <th scope="col">País</th>
          <th scope="col">Estatus</th>
          <th class="text-center" colspan="2"><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'logistic.edit')): ?> Editar <?php endif; ?>  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'logistic.destroy')): ?>/ Eliminar <?php endif; ?></th>
       </tr>
    </thead>
    <tbody>
       <?php $__currentLoopData = $logistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logistic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($logistic->name); ?></td>
            <td><?php echo e($logistic->phone); ?></td>
            <td><?php echo e($logistic->address); ?></td>
            <td><?php echo e($logistic->state); ?></td>
            <td><?php echo e($logistic->city); ?></td>
            <td><?php echo e($logistic->country); ?></td>
            <td><?php echo e($logistic->active); ?></td>
            <td colspan="2" class="text-center">
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'logistic.edit')): ?>
               <button wire:click="edit(<?php echo e($logistic->id); ?>)" class="btn btn-sm btn-outline-warning">
                  <i class="far fa-edit"></i>
               </button>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'logistic.destroy')): ?>
               <button wire:click="destroy(<?php echo e($logistic->id); ?>)" class="btn btn-sm btn-outline-danger">
                  <i class="fas fa-trash"></i>
               </button>
               <?php endif; ?>
            </td>
         </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
 </table>
 <?php echo e($logistics->links()); ?>

</div>
<?php endif; ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/logistic/table.blade.php ENDPATH**/ ?>