<div class="form-row">
    <div class="form-group col-md-3">
       <?php echo e(Form::label('type', 'Tipo')); ?>

       <?php echo e(Form::select('type', [
          'client' => 'Cliente',
          'farm' => 'Finca'
          ], null, ['class' => 'form-control', 'placeholder' => 'Seleccione tipo', 'id' => 'tipo'])); ?>

    </div>
    <div class="col-md-3 form-group finca">
      <?php echo e(Form::label('farm', 'Finca', ['class' => 'control-label'])); ?>

      <?php echo e(Form::select('farm', $farms, null, ['class' => 'form-control select-farm', 'placeholder' => 'Seleccione finca'])); ?>

    </div>
    <div class="col-md-3 form-group cliente">
      <?php echo e(Form::label('client', 'Cliente', ['class' => 'control-label'])); ?>

      <?php echo e(Form::select('client', $clients, null, ['class' => 'form-control select-client', 'placeholder' => 'Seleccione cliente'])); ?>

  </div>
    <div class="form-group col-md-3">
       <?php echo e(Form::label('color', 'Color')); ?>

        <input type="color" name="color" class="form-control">
    </div>
    <div class="form-group col-md-3">
      <?php echo e(Form::label('label', 'Etiqueta')); ?>

      <?php echo e(Form::select('label', [
         'square' => 'Cuadrado',
         'point' => 'Punto'
         ], null, ['class' => 'form-control', 'placeholder' => 'Seleccione Etiqueta'])); ?>

   </div>
   <div class="form-group col-md-3">
      <?php echo e(Form::label('load_type', 'Tipo de Carga')); ?>

      <?php echo e(Form::select('load_type', [
         'aereo' => 'Aéreo',
         'maritimo' => 'Marítimo'
         ], null, ['class' => 'form-control', 'placeholder' => 'Seleccione Tipo de Carga'])); ?>

   </div>
    <?php echo e(Form::hidden('id_user', Auth::user()->id)); ?>

    <?php echo e(Form::hidden('update_user', Auth::user()->id)); ?>

 </div>
 <?php $__env->startSection('scripts'); ?>
 <script>
   $(document).ready(function(){
        var tipo = $('#tipo').val();
        $('.cliente').hide();
        $('.finca').hide();
        $('#tipo').on('change', function() {
            if($('#tipo').val() == 'client'){
               console.log('cliente');
               $('.cliente').show();
               $('.finca').hide();
            }else if($('#tipo').val() == 'farm'){
               $('.finca').show();
               $('.cliente').hide();
               console.log('finca');
            }
        });
      
   });
 </script>
 <?php $__env->stopSection(); ?>
     <?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/color/partials/form.blade.php ENDPATH**/ ?>