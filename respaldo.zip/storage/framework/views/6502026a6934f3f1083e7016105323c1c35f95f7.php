<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'farm.index')): ?>
<h2>Listado de Fincas</h2>
<div class="table-responsive">
   <table class="table table-sm table-hover">
    <thead>
       <tr>
          <th scope="col">Nombre</th>
          <th scope="col">Nombre Comercial</th>
          <th scope="col">Teléfono</th>
          <th scope="col">Dirección</th>
          <th scope="col">Estado</th>
          <th scope="col">Ciudad</th>
          <th scope="col">País</th>
          <th class="text-center" colspan="2"><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'farm.edit')): ?> Editar <?php endif; ?>  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'farm.destroy')): ?>/ Eliminar <?php endif; ?></th>
       </tr>
    </thead>
    <tbody>
       <?php $__currentLoopData = $farms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($farm->name); ?></td>
            <td><?php echo e($farm->tradename); ?></td>
            <td><?php echo e($farm->phone); ?></td>
            <td><?php echo e($farm->address); ?></td>
            <td><?php echo e($farm->state); ?></td>
            <td><?php echo e($farm->city); ?></td>
            <td><?php echo e($farm->country); ?></td>
            <td colspan="2" class="text-center">
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'farm.edit')): ?>
               <button wire:click="edit(<?php echo e($farm->id); ?>)" class="btn btn-sm btn-outline-warning">
                  <i class="far fa-edit"></i>
               </button>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'farm.destroy')): ?>
               <button wire:click="destroy(<?php echo e($farm->id); ?>)" class="btn btn-sm btn-outline-danger">
                  <i class="fas fa-trash"></i>
               </button>
               <?php endif; ?>
            </td>
         </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
 </table>
 <?php echo e($farms->links()); ?>

</div>
<?php endif; ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/farm/table.blade.php ENDPATH**/ ?>