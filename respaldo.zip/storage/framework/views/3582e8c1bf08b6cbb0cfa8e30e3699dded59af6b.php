<div class="row">
    <div class="col-md-12">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'farm.create')): ?>
            <?php echo $__env->make("farm.$view", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
    <div class="col-md-12">
        <hr>
    </div>
    <div class="col-md-12">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'farm.index')): ?>
            <?php echo $__env->make('farm.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/livewire/farm-component.blade.php ENDPATH**/ ?>