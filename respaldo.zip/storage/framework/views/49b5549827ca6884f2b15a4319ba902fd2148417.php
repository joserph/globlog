<div class="form-row">
    <div class="form-group col-md-6">
        <?php echo e(Form::label('name', 'Nombre')); ?>

        <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

    </div>  
    <div class="form-group col-md-3">
        <?php echo e(Form::label('owner', 'Dueño')); ?>

        <?php echo e(Form::text('owner', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group col-md-3">
        <?php echo e(Form::label('phone', 'Teléfono')); ?>

        <?php echo e(Form::text('phone', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group col-md-9">
        <?php echo e(Form::label('address', 'Dirección')); ?>

        <?php echo e(Form::text('address', null, ['class' => 'form-control'])); ?>

    </div>
    
    <div class="form-group col-md-3">
        <?php echo e(Form::label('state', 'Estado / Provincia')); ?>

        <?php echo e(Form::text('state', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group col-md-3">
        <?php echo e(Form::label('city', 'Ciudad')); ?>

        <?php echo e(Form::text('city', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group col-md-3">
        <?php echo e(Form::label('country', 'Pais')); ?>

        <?php echo e(Form::text('country', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group col-md-4">
        <?php echo e(Form::label('email', 'Correo')); ?>

        <?php echo e(Form::email('email', null, ['class' => 'form-control'])); ?>

    </div>
    <?php if(isset($qa_company)): ?>
        <?php echo e(Form::hidden('update_user', Auth::user()->id)); ?>

    <?php else: ?>
        <?php echo e(Form::hidden('id_user', Auth::user()->id)); ?>

        <?php echo e(Form::hidden('update_user', Auth::user()->id)); ?>

    <?php endif; ?>
</div>    
	    <?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/qacompany/partials/form.blade.php ENDPATH**/ ?>