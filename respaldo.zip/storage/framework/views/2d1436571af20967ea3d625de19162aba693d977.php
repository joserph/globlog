

<?php $__env->startSection('title'); ?> Vuelos | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1>Vuelos
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'flight.create')): ?>
                  <a href="<?php echo e(route('flight.create')); ?>" class="btn btn-outline-primary"><i class="fas fa-plus-circle"></i></a>
               <?php endif; ?>
            </h1>
         </div>
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item active">Vuelos</li>
            </ol>
         </div>
      </div>
   </div><!-- /.container-fluid -->
</section>

<section class="content">
   <div class="container-fluid">
      <div class="row">
         <!-- /.col -->
         <div class="col-md-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'flight.index')): ?>
               <div class="card">
                  <div class="card-header">
                     <h3 class="card-title">Lista de Vuelos</h3>
                     <div class="card-tools">
                        <?php echo e($flights->links()); ?>

                     </div>
                  </div>
   
                  <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
   
                  <!-- /.card-header -->
                  <div class="card-body table-responsive p-0">
                     <table class="table table-sm">
                        <thead class="thead-dark">
                           <tr>
                              <th class="text-center" scope="col">AWB</th>
                              <th class="text-center" scope="col">Transportista</th>
                              <th class="text-center" scope="col">Código Termografo</th>
                              <th class="text-center" scope="col">Marca Termografo</th>
                              <th class="text-center" scope="col">Fecha Salida</th>
                              <th class="text-center" scope="col">Fecha Llegada</th>
                              <th class="text-center" scope="col">Tipo de AWB</th>
                              <th class="text-center" scope="col">Estatus</th>
                              <th class="text-center" scope="col">Ciudad Origen</th>
                              <th class="text-center" scope="col">País Origen</th>
                              <th class="text-center" scope="col">Ciudad Destino</th>
                              <th class="text-center" scope="col">País Destino</th>
                              
                              <th class="text-center" class="text-center" width="80px" colspan="3"><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'flight.show')): ?>Ver <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'flight.edit')): ?>Editar <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'flight.destroy')): ?>Eliminar <?php endif; ?></th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php $__currentLoopData = $flights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                 <td class="text-center"><?php echo e($flight->awb); ?></td>
                                 <td class="text-center">
                                    <?php if($flight->airline != NULL): ?>
                                       <?php echo e(Str::upper($flight->airline->name)); ?>

                                    <?php else: ?>
                                       <?php echo e(Str::upper($flight->carrier)); ?>

                                    <?php endif; ?>
                                 </td>
                                 <td class="text-center"><?php echo e($flight->code); ?></td>
                                 <td class="text-center"><?php echo e($flight->brand); ?></td>
                                 <td class="text-center"><?php echo e(date('d/m/Y', strtotime($flight->date))); ?></td>
                                 <td class="text-center"><?php echo e(date('d/m/Y', strtotime($flight->arrival_date))); ?></td>
                                 
                                 <td class="text-center">
                                    <?php if($flight->type_awb == 'own'): ?>
                                       <span class="badge badge-success">PROPIA</span>
                                    <?php else: ?>
                                       <span class="badge badge-secondary">EXTERNA</span>
                                    <?php endif; ?>
                                 </td>
                                 <td class="text-center">
                                    <?php if($flight->status == 'open'): ?>
                                       <span class="badge badge-primary"><i class="fas fa-lock-open"></i> ABIERTA</span>
                                    <?php else: ?>
                                       <span class="badge badge-dark"><i class="fas fa-lock"></i> CERRADA</span>
                                    <?php endif; ?>
                                 </td>
                                 <td class="text-center"><?php echo e($flight->origin_city); ?></td>
                                 <td class="text-center"><?php echo e($flight->origin_country); ?></td>
                                 <td class="text-center"><?php echo e($flight->destination_city); ?></td>
                                 <td class="text-center"><?php echo e($flight->destination_country); ?></td>
                                 <td width="45px" class="text-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'flight.show')): ?>
                                       <a href="<?php echo e(route('flight.show', $flight->id)); ?>" class="btn btn-outline-success btn-sm"><i class="fas fa-eye"></i></a>
                                    <?php endif; ?>
                                 </td>
                                 <td width="45px" class="text-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'flight.edit')): ?>
                                       <a href="<?php echo e(route('flight.edit', $flight->id)); ?>" class="btn btn-outline-warning btn-sm"><i class="fas fa-edit"></i></a>
                                    <?php endif; ?>
                                 </td>
                                 <td width="45px" class="text-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'flight.destroy')): ?>
                                       <?php echo e(Form::open(['route' => ['flight.destroy', $flight->id], 'method' => 'DELETE'])); ?>

                                          <?php echo e(Form::button('<i class="fas fa-trash-alt"></i> ' . '', ['type' => 'submit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'title' => 'Eliminar Vuelo', 'class' => 'btn btn-sm btn-outline-danger', 'onclick' => 'return confirm("¿Seguro de eliminar el vuelo?")'])); ?>

                                       <?php echo e(Form::close()); ?>

                                    <?php endif; ?>
                                 </td>
                              </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     </table>
                  </div>
                  <!-- /.card-body -->
               </div>
            <?php endif; ?>
            <!-- /.card -->
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/flight/index.blade.php ENDPATH**/ ?>