<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>FACTURAS FINCAS <?php echo e($invoiceheaders->bl); ?></title>
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
        }
        .text-center{
            text-align: center;
        }
        .text-right{
            text-align: right;
            padding-right: 5px;
        }
        .text-left{
            text-align: left;
            padding-left: 5px;
        }
        table {
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
            height: 20px;
        }
        table{
            width: 100%;
        }
        .small-letter{
            font-size: 8px;
        }
        .medium-letter{
            font-size: 12px;
        }
        
        table.sinb{
            margin: 0 auto;
            width: 60%;
        }
        table.sinb, th, td{
            border: 1px solid black;
            height: 15px;
        }
        .text-white{
            color: #fff;
        }
        h1{
            font-size: 39px;
        }
        
         .medio{
            width: 120px;
         }
         .espacio{
            width: 10px;
         }
         .completo{
            width: 243px;
         }
         .mitad{
            width: 340px;
         }
         .sin-border1{
            border-top: 1px solid white;
            border-right: 1px solid white;
            border-bottom: 1px solid white;
            border-left: 1px solid white;
        }
        .sin-border2{
            border-top: 1px solid white;
            border-right: 1px solid white;
            border-bottom: 1px solid black;
            border-left: 1px solid white;
        }
        .sin-border3{
            border-top: 1px solid white;
            border-right: 1px solid black;
            border-bottom: 1px solid white;
            border-left: 1px solid white;
        }
        .sin-border4{
            border-top: 1px solid black;
            border-right: 1px solid black;
            border-bottom: 1px solid white;
            border-left: 1px solid black;
        }
         .altura{
            height: 50px;
         }
    </style>
</head>
<body>
   <?php $__currentLoopData = $invoiceItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <h1 class="text-center">COMERCIAL INVOICE</h1>
      <table>
         <tr>
            <th>Grower Name & Address</th>
            <th class="espacio sin-border1"> </th>
            <th class="medio sin-border1">Farm Code</th>
            <th class="medio sin-border1">Date</th>
         </tr>
         <tr>
            <td class="sin-border4 medium-letter"><?php echo e($item['name']); ?></td>
            <td class="sin-border1"></td>
            <td class="sin-border1"></td>
            <td class="text-center sin-border1 medium-letter"><?php echo e(date('d/m/Y', strtotime($invoiceheaders->date))); ?></td>
         </tr>
         <tr>
            <td class="sin-border4 medium-letter"><?php echo e($item['address_farm']); ?> - <?php echo e($item['city_farm']); ?>.</td>
            <td class="sin-border1"></td>
            <th class="sin-border1">Country Code</th>
            <th class="sin-border1">Invoice Nº</th>
         </tr>
         <tr>
            <td class="medium-letter">PHONE: <?php echo e($item['phone_farm']); ?></td>
            <td class="sin-border1"></td>
            <td class="sin-border1"></td>
            <td class="sin-border1"></td>
         </tr>
      </table>
      <br>
      <table>
         <tr>
            <th>Marketing Name / Marca De Comercialización</th>
            <th class="espacio sin-border1"> </th>
            <th class="completo sin-border2">B/L N#</th>
         </tr>
         <tr>
            <td class="sin-border4 medium-letter"><?php echo e($item['client']); ?></td>
            <td class="sin-border3"></td>
            <td class="text-center medium-letter"><?php echo e($invoiceheaders->bl); ?></td>
         </tr>
         <tr>
            <td class="sin-border4 medium-letter"><?php echo e($item['address_client']); ?>. <?php echo e($item['city_client']); ?>, <?php echo e($item['state_client']); ?> - <?php echo e($item['country_client']); ?>.</td>
            <td class="sin-border1"></td>
            <th class="sin-border2">Carrier</td>
         </tr>
         <tr>
            <td class="medium-letter">PHONE: <?php echo e($item['phone_client']); ?></td>
            <td class="sin-border3"></td>
            <td class="text-center medium-letter"><?php echo e($item['carrier']); ?></td>
         </tr>
      </table>
      <br>
      <table>
         <tr>
            <th>Foreign Purchaser Consignee</th>
            <th class="espacio sin-border1"> </th>
            <th class="completo sin-border2">Hawb</th>
         </tr>
         <tr>
            <td class="sin-border4 medium-letter"><?php echo e($company->name); ?></td>
            <td class="sin-border3"></td>
            <td class="text-center medium-letter"><?php echo e($item['hawb']); ?></td>
         </tr>
         <tr>
            <td class="sin-border4 medium-letter"><?php echo e($company->address); ?>. <?php echo e($company->city); ?>, <?php echo e($company->state); ?> - <?php echo e($company->country); ?>.</td>
            <td class="sin-border1"></td>
            <th class="sin-border2">#Refrendo</th>
         </tr>
         <tr>
            <td class="medium-letter">PHONE: <?php echo e($company->phone); ?></td>
            <td class="sin-border3"></td>
            <td></td>
         </tr>
      </table>
      <br>
      <table>
         <tr>
            <th>Pcs</th>
            <th>Bxs</th>
            <th>Product Description</th>
            <th>Atpa</th>
            <th>Hts #</th>
            <th>Units</th>
            <th>Stems</th>
            <th>Price</th>
            <th>Price Total</th>
         </tr>
         <tr>
            <td class="text-center medium-letter"><?php echo e($item['pieces']); ?></td>
            <td class="text-center medium-letter"><?php echo e(number_format($item['fulls'], 3, '.','')); ?></td>
            <td class="medium-letter"><?php echo e($item['variety']); ?></td>
            <td class="text-center medium-letter">-</td>
            <td class="text-center medium-letter">-</td>
            <td class="text-center medium-letter"><?php echo e($item['bunches']); ?></td>
            <td class="text-center medium-letter"><?php echo e(number_format($item['stems'], 0, '','.')); ?></td>
            <td class="text-center medium-letter"><?php echo e(number_format($item['price'], 2, ',','')); ?></td>
            <td class="text-center medium-letter"><?php echo e(number_format($item['total'], 2, ',','.')); ?></td>
         </tr>
         <tr>
            <td class="text-center medium-letter"><?php echo e($item['pieces']); ?></td>
            <td class="text-center medium-letter"><?php echo e(number_format($item['fulls'], 3, '.','')); ?></td>
            <td class="text-center medium-letter" colspan="3">Total</td>
            <td class="text-center medium-letter"><?php echo e($item['bunches']); ?></td>
            <td class="text-center medium-letter" colspan="2"></td>
            <td class="text-center medium-letter"><?php echo e(number_format($item['total'], 2, ',','.')); ?></td>
         </tr>
      </table>
      <br>
      <table>
         <tr>
            <th colspan="2">TOTAL</th>
         </tr>
         <tr>
            <th>Product Description</th>
            <th>Stems</th>
         </tr>
         <tr>
            <td class="text-center medium-letter"><?php echo e($item['variety']); ?></td>
            <td class="text-center medium-letter"><?php echo e($item['stems']); ?></td>
         </tr>
      </table>
      <br>
      <table>
         <tr>
            <th class="mitad">Name and title of person preparing invoice</th>
            <th class="espacio sin-border3"> </th>
            <th class="mitad">Freight Forwarder</th>
         </tr>
         <tr>
            <td class="sin-border4"></td>
            <td class="sin-border3"></td>
            <td class="sin-border4 medium-letter"><?php echo e($lc_active->name); ?></td>
         </tr>
         <tr>
            <td class="sin-border4"></td>
            <td class="sin-border3"></td>
            <td class="sin-border4 medium-letter"><?php echo e($lc_active->address); ?></td>
         </tr>
         <tr>
            <td class="sin-border4"></td>
            <td class="sin-border3"></td>
            <td class="sin-border4 medium-letter"></td>
         </tr>
         <tr>
            <td></td>
            <td class="sin-border3"></td>
            <td class="medium-letter"><?php echo e($lc_active->city); ?>-<?php echo e($lc_active->country); ?></td>
         </tr>
      </table>
      <br>
      <table>
         <tr>
            <th class="mitad altura"> </th>
            <th class="espacio sin-border3"> </th>
            <th class="mitad"> </th>
         </tr>
         <tr>
            <th>Customs Use Only</th>
            <th class="sin-border3"></th>
            <th>Usda Aphis Ppq Use Only</th>
         </tr>
      </table>
      <div style="page-break-after:always;"></div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   


</body>
</html><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/masterinvoice/farmsInvoicePdf.blade.php ENDPATH**/ ?>