<div class="row">
    <div class="col-md-12">
        <?php echo $__env->make("logistic.$view", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-md-12">
        <hr>
    </div>
    <div class="col-md-12">
        <?php echo $__env->make('logistic.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/livewire/logistic-company-component.blade.php ENDPATH**/ ?>