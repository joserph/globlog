<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'logistic.edit')): ?>
<h2>Editar Empresa de logística</h2>
<?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php echo $__env->make('logistic.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<button type="button" wire:click="update" class="btn btn-outline-warning">
    <i class="fas fa-sync"></i> Actualizar
</button>

<button wire:click="default" class="btn btn-outline-secondary">
    <i class="fas fa-ban"></i> Cancelar
</button>
<?php endif; ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/logistic/edit.blade.php ENDPATH**/ ?>