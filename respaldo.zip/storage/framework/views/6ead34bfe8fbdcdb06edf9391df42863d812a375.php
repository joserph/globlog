<div class="row">
    <div class="col-md-12">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'client.create')): ?>
            <?php echo $__env->make("client.$view", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
    <div class="col-md-12">
        <hr>
    </div>
    <div class="col-md-12">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'client.index')): ?>
            <?php echo $__env->make('client.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\app-ffc\resources\views/livewire/client-component.blade.php ENDPATH**/ ?>