<div class="row">
    <div class="col-md-4 form-group">
        <?php echo e(Form::label('id_farm', 'Finca', ['class' => 'control-label'])); ?>

        
        <select class="form-control" name="id_farm" id="id_farmEdit">
            <option value="">Seleccione finca</option>
            <?php $__currentLoopData = $farmsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemFarm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($itemFarm->id); ?>" <?php echo e($itemFarm->id == $item->id_farm ? 'selected' : ''); ?>><?php echo e($itemFarm->name); ?> <?php echo e($itemFarm->tradename); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-3 form-group">
        <?php echo e(Form::label('id_client', 'Cliente', ['class' => 'control-label'])); ?>

        
        <select class="form-control" name="id_client" id="id_clientEdit">
            <option value="">Seleccione cliente</option>
            <?php $__currentLoopData = $clientsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemClient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($itemClient->id); ?>" <?php echo e($itemClient->id == $item->id_client ? 'selected' : ''); ?>><?php echo e(str_replace('SAG-', '', $itemClient->name)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-3 form-group">
        <?php echo e(Form::label('variety_id', 'Variedad', ['class' => 'control-label'])); ?>

        <?php echo e(Form::select('variety_id', $varieties, null, ['class' => 'form-control select-product', 'placeholder' => 'Seleccione tipo'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('hawb', 'HAWB', ['class' => 'control-label'])); ?>

        <?php if($flight->type_awb == 'own'): ?>
            <?php echo e(Form::text('hawb', null, ['class' => 'form-control', 'readonly'])); ?>

        <?php else: ?>
            <?php echo e(Form::text('hawb', null, ['class' => 'form-control'])); ?>

        <?php endif; ?>
    </div>
    <h5 class="col-sm-12">
        <p class="lead">Coordinado</p>
        <hr>
    </h5>
    <div class="col-sm-2">
        <?php echo e(Form::label('hb', 'HB Coordinado', ['class' => 'control-label'])); ?>

        <?php echo e(Form::number('hb', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('qb', 'QB Coordinado', ['class' => 'control-label'])); ?>

        <?php echo e(Form::number('qb', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('eb', 'EB Coordinado', ['class' => 'control-label'])); ?>

        <?php echo e(Form::number('eb', null, ['class' => 'form-control'])); ?>

    </div>
    <h5 class="col-sm-12">
        <br>
        <p class="lead">Recibido</p>
        <hr>
    </h5>
    <h5 class="col-sm-12">Recibidos</h5>
    <div class="col-sm-2">
        <?php echo e(Form::label('hb_r', 'HB Recibido', ['class' => 'control-label'])); ?>

        <?php echo e(Form::number('hb_r', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('qb_r', 'QB Recibido', ['class' => 'control-label'])); ?>

        <?php echo e(Form::number('qb_r', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('eb_r', 'EB Recibido', ['class' => 'control-label'])); ?>

        <?php echo e(Form::number('eb_r', null, ['class' => 'form-control'])); ?>

    </div>

    <div class="col-sm-2">
        <?php echo e(Form::label('returns', 'Devolución', ['class' => 'control-label'])); ?>

        <?php echo e(Form::number('returns', null, ['class' => 'form-control'])); ?>

    </div>
    
    <div class="col-sm-4">
        <?php echo e(Form::label('observation', 'Observación', ['class' => 'control-label'])); ?>

        <?php echo e(Form::textarea('observation', null, ['class' => 'form-control', 'rows' => '4', 'cols' => '50'])); ?>

    </div>
    <div class="col-md-5 form-group">
        <?php echo e(Form::label('id_marketer', 'Comercializadora', ['class' => 'control-label'])); ?>

        <?php echo e(Form::select('id_marketer', $marketers, null, ['class' => 'form-control', 'placeholder' => 'Seleccione Comercializadora'])); ?>

    </div>
    <div class="col-sm-4 form-check">
        <input type="checkbox" class="form-check-input" name="duplicate" <?php if($item->duplicate == 'yes'): ?> checked <?php endif; ?> id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Es una Guía duplicada</label>
    </div>
    
    
    <?php echo e(Form::hidden('id_hawb', $item->id_hawb, ['id' => 'id_hawb'])); ?>

    <?php echo e(Form::hidden('update_user', Auth::user()->id, ['id' => 'update_user'])); ?>

    <?php echo e(Form::hidden('id_flight', $flight->id, ['id' => 'id_flight'])); ?>

</div>

<?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/distribution/partials/formEdit.blade.php ENDPATH**/ ?>