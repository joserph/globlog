

<?php $__env->startSection('title'); ?> Crear Maritimo | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="container-fluid">
       <div class="row mb-2">
          <div class="col-sm-6">
             <h1>Crear Maritimo
                
             </h1>
          </div>
          <div class="col-sm-6">
             <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('load.index')); ?>">Maritimos</a></li>
                <li class="breadcrumb-item active">Crear Maritimo</li>
             </ol>
          </div>
       </div>
    </div><!-- /.container-fluid -->
 </section>



<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Crear Maritimo
                </div>

                <div class="card-body">
                    
                   <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                     <?php echo e(Form::open(['route' => 'load.store', 'class' => 'form-horizontal'])); ?>

                        <?php echo $__env->make('load.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <hr>
                        <div class="form-group row">
                           <div class="col-sm-12">
                              <button type="submit" class="btn btn-outline-primary"><i class="fas fa-plus-circle"></i></button>
                           </div>
                        </div>
                     <?php echo e(Form::close()); ?>

                    
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
   <script>
      let num_pallet = document.getElementById('hide')
      num_pallet.style.display = 'none'
      let piso = document.getElementById('floor')
      let pallet = document.getElementById('num_pallets')

      piso.addEventListener('change', (e) => {
         if(piso.value === 'si')
         {
            num_pallet.style.display = 'block'
         }else{
            num_pallet.style.display = 'none'
            pallet.value = 0
         }
      });
      
   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/load/create.blade.php ENDPATH**/ ?>