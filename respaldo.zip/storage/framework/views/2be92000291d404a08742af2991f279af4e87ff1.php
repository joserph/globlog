

<?php $__env->startSection('title'); ?> Plano de Carga | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1>Plano de Carga</h1>
         </div>
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item"><a href="<?php echo e(route('load.index')); ?>">Cargas</a></li>
               <li class="breadcrumb-item"><a href="<?php echo e(route('load.show', $load->id)); ?>"><?php echo e($load->bl); ?></a></li>
               <li class="breadcrumb-item active">Plano de Carga</li>
            </ol>
         </div>
      </div>
   </div><!-- /.container-fluid -->
</section>

  <!-- Main content -->
<section class="content">
   <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
   <div class="container-fluid">
      <div class="row">
         <!-- /.col -->
         <div class="col-md-12">
            <?php echo e(Form::open(['route' => 'sketches.store'])); ?>

               <?php echo Form::hidden('id_load', $load->id); ?>

               <?php echo Form::hidden('id_user', \Auth::user()->id); ?>

               <?php echo Form::hidden('update_user', \Auth::user()->id); ?>

               <?php if($space != 1): ?>
               <?php echo Form::label('quantity', 'Seleccione la cantidad de espacios'); ?>

               <?php echo Form::select('quantity', [
                  '18' => '18', 
                  '20' => '20',
                  '22' => '22',
                  '24' => '24'
                  ], 20, ['placeholder' => 'Seleccione espacios', 'class' => 'form-control col-md-3']); ?>

               <?php endif; ?>
               <button type="submit" class="btn btn-sm btn-primary" <?php if($space == 1): ?> disabled <?php endif; ?>><i class="fas fa-plus-circle"></i> Generar espacios</button>
            <?php echo e(Form::close()); ?>

            <?php if($space == 1): ?>
               <?php echo Form::open(['route' => ['sketches.destroy', $load->id], 'method' => 'DELETE', 'onclick' => 'return confirm("¿Seguro de revertir los espacios?")']); ?>

                  <button class="btn btn-sm btn-outline-warning" data-toggle="tooltip" data-placement="top" title="Revertir espacios"><i class="fas fa-history"></i> Revertir Espacios</button>
               <?php echo Form::close(); ?>

            <?php endif; ?>

            <div class="card">
               <div class="card-header"></div>
               <div class="card-body">
                  <div class="row">
                     <?php $__currentLoopData = $sketches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col">
                        <div class="card <?php if($item->id_pallet): ?> card-success <?php else: ?> card-default <?php endif; ?> collapsed-card">
                           <div class="card-header">
                              <h5 class="card-title">
                                 Espacio 
                                 <span class="badge rounded-pill bg-dark"><?php echo e($item->space); ?></span>
                                 <?php if($item->id_pallet): ?>
                                    <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editModal<?php echo e($key); ?>" data-toggle="tooltip" data-placement="top" title="Editar paleta en espacio">
                                       <i class="fas fa-edit"></i> Editar
                                    </button>
                                    Paleta <span class="badge rounded-pill bg-info text-dark"><?php echo e($item->pallet->number); ?></span>
                                 <?php else: ?> 
                                    <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#myModal<?php echo e($key); ?>" data-toggle="tooltip" data-placement="top" title="Agregar paleta en espacio">
                                       <i class="fas fa-plus-circle"></i> Agregar 
                                       
                                    </button>
                                 <?php endif; ?>
                              </h5>
                              <!-- Modal Pallet -->
                                 <?php echo $__env->make('sketches.partials.addPallet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                              <!-- /Modal Pallets -->
                              <!-- Edit modal -->
                                 <?php echo $__env->make('sketches.partials.editPallet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                              <!-- /Edit modal -->
                             <div class="card-tools">
                               <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i>
                               </button>
                             </div>
                             <!-- /.card-tools -->
                           </div>
                           <!-- List Pallet -->
                              <?php echo $__env->make('sketches.partials.listPallet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                           <!-- /List Pallet -->
                         </div>
                     </div>
                     <?php if($key % 2 != 0): ?>
                        <div class="w-100"></div>
                     <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
               </div>
            </div>
            <div class="card">
               <div class="card-header">
                  Plano de Carga contenedor #<?php echo e($load->shipment); ?>

               </div>
               <div class="card-body">
                  <div class="row">
                     <?php $__currentLoopData = $sketches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                           <div class="row" style="height: 200px; border-style: solid; border-radius: 1px; border-width: 5px; padding-right: 0; padding-left: 0;">
                              <div class="col-4">
                                 <?php $__currentLoopData = $pallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $palle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($palle->id == $item->id_pallet): ?>
                                       <?php echo e($palle->counter); ?>

                                    <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                              <div class="col-8">
                                 <?php $__currentLoopData = $sketchPercent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $percent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->id_pallet == $percent->id_pallet): ?>
                                       <?php if($percent->percent < 10): ?>
                                          <?php
                                             $newPercent = $percent->percent + 10;
                                          ?>
                                       <?php elseif($percent->percent > 90 && $percent->percent < 100): ?>
                                          <?php
                                             $newPercent = $percent->percent - 10;
                                          ?>
                                       <?php else: ?>
                                          <?php
                                             $newPercent = $percent->percent;
                                          ?>
                                       <?php endif; ?>
                                       <div style="height: <?php echo e($newPercent); ?>%; 
                                       background-color: 
                                       <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($color->id_type == $percent->id_client): ?>
                                          <?php echo e($color->color); ?>

                                          <?php endif; ?>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       "><?php echo e($percent->client->name); ?></div>
                                    <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                           </div>
                        </div>
                        <?php if($key % 2 != 0): ?>
                           <div class="w-100"></div>
                        <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <div class="container">
                     <div class="row">
                        
                        <?php $__currentLoopData = $sketches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                           <div class="col" style="height: 200px; border-style: solid; border-radius: 1px; border-width: 5px; padding-right: 0; padding-left: 0;">
                              <div class="col">
                                 <?php $__currentLoopData = $pallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $palle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($palle->id == $item->id_pallet): ?>
                                       <?php echo e($palle->counter); ?>

                                    <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                              <div class="espacio" style="height: 100%; width: 100%;">
                                 <?php $__currentLoopData = $sketchPercent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $percent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->id_pallet == $percent->id_pallet): ?>
                                             <?php if($percent->percent < 10): ?>
                                                <?php
                                                   $newPercent = $percent->percent + 10;
                                                ?>
                                             <?php elseif($percent->percent > 90 && $percent->percent < 100): ?>
                                                <?php
                                                   $newPercent = $percent->percent - 10;
                                                ?>
                                             <?php else: ?>
                                                <?php
                                                   $newPercent = $percent->percent;
                                                ?>
                                             <?php endif; ?>
                                             <div style="height: <?php echo e($newPercent); ?>%; 
                                             background-color: 
                                             <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($color->id_type == $percent->id_client): ?>
                                                <?php echo e($color->color); ?>

                                                <?php endif; ?>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             "><?php echo e($percent->client->name); ?></div>
                                          
                                       
                                    <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                              </div>
                           </div>
                           <?php if($key % 2 != 0): ?>
                              <div class="w-100"></div>
                           <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

                        
                     </div>
                     <hr>
                     
                     
                          
                      
                     
                      
                  </div>
                </div>
               
               <!-- /.card-body -->
            </div>
            <div class="card-footer text-muted">
               <div class="container">
                  <div class="row">
                     <?php
                        $totalBoxes = 0;
                     ?>
                  <?php $__currentLoopData = $pallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     
                     
                          <div class="col-sm-6">
                           <li class="list-group-item d-flex justify-content-between align-items-center">
                              Paleta - <?php echo e($item->number); ?>

                              <span class="badge bg-primary rounded-pill"><?php echo e($item->quantity); ?> <?php echo e($item->usda ? '- USDA' : ''); ?></span>
                              </li>
                          </div>
                          <?php
                              $totalBoxes+= $item->quantity;
                           ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <hr>

                  <div class="col-sm-6">
                     <li class="list-group-item list-group-item-info d-flex justify-content-between align-items-center">
                        Total de cajas: 
                        <span class="badge bg-dark rounded-pill"><?php echo e($totalBoxes); ?></span>
                        </li>
                    </div>
               </div>
            </div>
             </div>
            <!-- /.card -->
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/sketches/index.blade.php ENDPATH**/ ?>