<div class="form-row">
    <div class="form-group col-md-6">
        <?php echo e(Form::label('name', 'Nombre')); ?>

        <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

    </div>  
    <div class="form-group col-md-3">
        <?php echo e(Form::label('ruc', 'RUC')); ?>

        <?php echo e(Form::text('ruc', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group col-md-3">
        <?php echo e(Form::label('phone', 'Teléfono')); ?>

        <?php echo e(Form::text('phone', null, ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group col-md-4">
        <?php echo e(Form::label('email', 'Correo')); ?>

        <?php echo e(Form::email('email', null, ['class' => 'form-control'])); ?>

    </div>
    <?php if(isset($dae)): ?>
        <?php echo e(Form::hidden('update_user', Auth::user()->id)); ?>

    <?php else: ?>
        <?php echo e(Form::hidden('id_user', Auth::user()->id)); ?>

        <?php echo e(Form::hidden('update_user', Auth::user()->id)); ?>

    <?php endif; ?>
</div>    
	    <?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/airline/partials/form.blade.php ENDPATH**/ ?>