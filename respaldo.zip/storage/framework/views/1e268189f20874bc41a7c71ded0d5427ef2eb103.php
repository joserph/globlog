<div class="form-group row">
    <?php echo e(Form::label('name', 'Nombre', ['class' => 'col-sm-2 control-label'])); ?>

    <div class="col-sm-10">
        <?php echo e(Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Nombre'])); ?>

    </div>
</div>

<div class="form-group row">
    <?php echo e(Form::label('email', 'Correo', ['class' => 'col-sm-2 control-label'])); ?>

    <div class="col-sm-10">
        <?php echo e(Form::text('email', null, ['class' => 'form-control', 'placeholder' => 'Correo'])); ?>

    </div>
</div>

<?php if(Auth::user()->roles[0]->full_access != 'no'): ?>
<div class="form-group row">
    <?php echo e(Form::label('roles', 'Role', ['class' => 'col-sm-2 control-label'])); ?>

    <div class="col-sm-10">
        <?php echo e(Form::select('roles', $roles, null, ['class' => 'form-control', 'placeholder' => 'Seleccione role'])); ?>

    </div>
</div>
<?php else: ?> 
    <?php echo e(Form::hidden('roles', $user->roles[0]->id)); ?>

<?php endif; ?>
<?php /**PATH C:\laragon\www\app-ffc\resources\views/user/partials/formE.blade.php ENDPATH**/ ?>