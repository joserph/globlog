<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'client.create')): ?>
<h2>Crear cliente</h2>
<?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php echo $__env->make('client.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<button wire:click="store" class="btn btn-outline-primary" id="createClient" data-toggle="tooltip" data-placement="top" title="Crear Cliente">
    <i class="fas fa-plus-circle"></i> Crear
</button>
<?php endif; ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/client/create.blade.php ENDPATH**/ ?>