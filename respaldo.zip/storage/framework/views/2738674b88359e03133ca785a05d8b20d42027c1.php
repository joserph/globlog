

<?php $__env->startSection('title'); ?> Lista de usuarios | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1>Usuarios</h1>
         </div>
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item active">Usuarios</li>
            </ol>
         </div>
      </div>
   </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">
   <div class="container-fluid">
      <div class="row">
         <!-- /.col -->
         <div class="col-md-12">
            <div class="card">
               <div class="card-header">
                  Lista de usuarios

                  <div class="card-tools">
                     <?php echo e($users->links()); ?>

                  </div>
               </div>

               <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

               <!-- /.card-header -->
               <div class="card-body table-responsive p-0">
                  <table class="table">
                     <thead>
                        <tr>
                           <th class="text-center" scope="col">#</th>
                           <th class="text-center" scope="col">Nombre</th>
                           <th class="text-center" scope="col">Email</th>
                           <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'role.index')): ?>
                              <th class="text-center" scope="col">Role(s)</th>
                           <?php endif; ?>
                           <th class="text-center" colspan="3">&nbsp;</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td class="text-center"><?php echo e($user->id); ?></td>
                           <td class="text-center"><?php echo e($user->name); ?></td>
                           <td class="text-center"><?php echo e($user->email); ?></td>
                           <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'role.index')): ?>
                              <td class="text-center">
                                 <?php if(isset($user->roles[0]->name)): ?>
                                    <?php echo e($user->roles[0]->name); ?>

                                 <?php endif; ?>
                              </td>
                           <?php endif; ?>
                           <td width="100px" class="text-center">
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', [$user, ['user.show', 'userown.show']])): ?>
                                 <a href="<?php echo e(route('user.show', $user->id)); ?>" class="btn btn-info btn-sm"><i class="fas fa-eye"></i> Ver</a>
                              <?php endif; ?>
                           </td>
                           <td width="100px" class="text-center">
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', [$user, ['user.edit', 'userown.edit']])): ?>
                                 <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Editar</a>
                              <?php endif; ?>
                           </td>
                           <td width="120px" class="text-center">
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'user.destroy')): ?>
                                 <?php echo e(Form::open(['route' => ['user.destroy', $user->id], 'method' => 'DELETE'])); ?>

                                    <?php echo e(Form::button('<i class="fas fa-trash-alt"></i> ' . 'Eliminar', ['type' => 'submit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'title' => 'Eliminar usuario', 'class' => 'btn btn-sm btn-danger', 'onclick' => 'return confirm("¿Seguro de eliminar el usuario?")'])); ?>

                                 <?php echo e(Form::close()); ?>

                              <?php endif; ?>
                           </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                  </table>
               </div>
               <!-- /.card-body -->
            </div>
            <!-- /.card -->
         </div>
      </div>
   </div>
</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/user/index.blade.php ENDPATH**/ ?>