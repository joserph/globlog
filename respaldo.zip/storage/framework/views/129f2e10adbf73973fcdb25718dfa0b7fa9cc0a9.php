<div class="row">
    <div class="col-md-12 form-group">
        <?php echo e(Form::label('id_farm', 'Finca', ['class' => 'control-label'])); ?>

        <div class="input-group mb-12">
            <select class="form-control" name="id_farm" id="farmsList_<?php echo e($item->id); ?>">
                <option value="">Seleccione finca</option>
                <?php $__currentLoopData = $farmsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemFarm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($itemFarm->id); ?>"><?php echo e($itemFarm->name); ?> <?php echo e($itemFarm->tradename); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col-md-12 form-group">
        <?php echo e(Form::label('id_client', 'Cliente', ['class' => 'control-label'])); ?>

        <div class="input-group mb-12">
            <select class="form-control" name="id_client" id="clientsList_<?php echo e($item->id); ?>">
                <option value="">Seleccione cliente</option>
                <?php $__currentLoopData = $clientsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemClient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($itemClient->id); ?>"><?php echo e(str_replace('SAG-', '', $itemClient->name)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div>
<div class="row">
    <div class="col form-group">
        <?php echo e(Form::label('hb', 'HB', ['class' => 'control-label'])); ?>

        <div class="input-group mb-12">
            <input type="number" name="hb" id="hb_<?php echo e($item->id); ?>" value="0" class="form-control grupo">
        </div>
    </div>
    <div class="col form-group">
        <?php echo e(Form::label('qb', 'QB', ['class' => 'control-label'])); ?>

        <div class="input-group mb-12">
            <input type="number" name="qb" id="qb_<?php echo e($item->id); ?>" value="0" class="form-control grupo">
        </div>
    </div>
</div>
<div class="row">
    <div class="col form-group">
        <?php echo e(Form::label('eb', 'EB', ['class' => 'control-label'])); ?>

        <div class="input-group mb-12">
            <input type="number" name="eb" id="eb_<?php echo e($item->id); ?>" value="0" class="form-control grupo">
        </div>
    </div>
    <div class="col form-group">
        <?php echo e(Form::label('quantity', 'Total', ['class' => 'control-label'])); ?>

        <div class="input-group mb-12">
            <input type="number" name="quantity" id="total_<?php echo e($item->id); ?>" value="0" class="form-control grupo" readonly>
        </div>
    </div>
</div>
<div class="row">
    <div class="col form-group">
        <?php echo e(Form::label('piso', 'Piso', ['class' => 'control-label'])); ?>

        <div class="input-group mb-12">
            <?php echo e(Form::checkbox('piso', 'value', false)); ?>

        </div>
    </div>
</div>




<?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/palletitems/partials/form.blade.php ENDPATH**/ ?>