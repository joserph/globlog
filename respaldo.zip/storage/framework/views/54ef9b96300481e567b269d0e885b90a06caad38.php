<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'varieties.index')): ?>
<h2>Listado tipos de variedades</h2>
<div class="table-responsive">
   <table class="table table-sm table-hover">
    <thead>
       <tr>
          <th scope="col">Nombre</th>
          <th class="text-center" colspan="2"><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'variety.edit')): ?> Editar <?php endif; ?>  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'variety.destroy')): ?>/ Eliminar <?php endif; ?></th>
       </tr>
    </thead>
    <tbody>
       <?php $__currentLoopData = $varieties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variety): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($variety->name); ?></td>
            <td><?php echo e($variety->scientific_name); ?></td>
            <td colspan="2" class="text-center">
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'variety.edit')): ?>
               <button wire:click="edit(<?php echo e($variety->id); ?>)" class="btn btn-sm btn-outline-warning">
                  <i class="far fa-edit"></i>
               </button>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'variety.destroy')): ?>
               <button wire:click="destroy(<?php echo e($variety->id); ?>)" class="btn btn-sm btn-outline-danger">
                  <i class="fas fa-trash"></i>
               </button>
               <?php endif; ?>
            </td>
         </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
 </table>
 <?php echo e($varieties->links()); ?>

</div>
<?php endif; ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/variety/table.blade.php ENDPATH**/ ?>