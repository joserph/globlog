

<?php $__env->startSection('title'); ?> Maritimos | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1>Maritimos
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'load.create')): ?>
                  <a href="<?php echo e(route('load.create')); ?>" class="btn btn-outline-primary"><i class="fas fa-plus-circle"></i></a>
               <?php endif; ?>
            </h1>
         </div>
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item active">Maritimos</li>
            </ol>
         </div>
      </div>
   </div><!-- /.container-fluid -->
</section>

<section class="content">
   <div class="container-fluid">
      <div class="row">
         <!-- /.col -->
         <div class="col-md-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'load.index')): ?>
               <div class="card">
                  <div class="card-header">
                     <h3 class="card-title">Lista de Maritimos</h3>
                     <div class="card-tools">
                        <?php echo e($loads->links()); ?>

                     </div>
                  </div>
   
                  <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
   
                  <!-- /.card-header -->
                  <div class="card-body table-responsive p-0">
                     <table class="table table-sm">
                        <thead class="thead-dark">
                           <tr>
                              <th class="text-center" scope="col">N°</th>
                              <th class="text-center" scope="col">Año</th>
                              <th class="text-center" scope="col">BL</th>
                              <th class="text-center" scope="col">Booking</th>
                              <th class="text-center" scope="col">Agencia</th>
                              <th class="text-center" scope="col">Sellos</th>
                              <!--<th class="text-center" scope="col">Transportista</th>-->
                              <th class="text-center" scope="col">Fecha Salida</th>
                              <th class="text-center" scope="col">Fecha Llegada</th>
                              <th class="text-center" scope="col">Termografo Fondo</th>
                              <th class="text-center" scope="col">Termografo Puerta</th>
                              <th class="text-center" scope="col">Clientes</th>
                              <th class="text-center" scope="col">Coordinado</th>
                              <th class="text-center" scope="col">Embarcado</th>
                              <th class="text-center" scope="col">Estatus de viaje</th>
                              <th class="text-center" width="80px" colspan="3"><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'load.show')): ?>Ver <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'load.edit')): ?>Editar <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'load.destroy')): ?>Eliminar <?php endif; ?></th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php $__currentLoopData = $loads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $load): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php
                                 $llegada = strtotime($load->arrival_date);
                                 $salida = strtotime($load->date);
                                 $dife = ($llegada - $salida);
                              ?>
                              
                              <tr>
                                 <td class="text-center"><?php echo e($load->shipment); ?></td>
                                 <td class="text-center"><?php echo e(date('Y', strtotime($load->date))); ?></td>
                                 <td class="text-center"><?php echo e($load->bl); ?></td>
                                 <td class="text-center"><?php echo e($load->booking); ?></td>
                                 <td class="text-center">
                                    <?php $__currentLoopData = $logistics_companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($load->id_logistic_company == $item->id): ?>
                                          <?php echo e(Str::limit($item->name, 15, '...')); ?>

                                       <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </td>
                                 <td>
                                    <button 
                                       type="button" 
                                       class="btn btn-outline-info btn-sm test" 
                                       data-toggle="popover" 
                                       title="Sellos" 
                                       data-content="
                                       CONTENEDOR N° --------> <?php echo e($load->container_number); ?>

                                       SELLO BOTELLA ---------> <?php echo e($load->seal_bottle); ?>

                                       SELLO CABLE ------------> <?php echo e($load->seal_cable); ?>

                                       SELLO STICKER ----------> <?php echo e($load->seal_sticker); ?>

                                       "
                                       >Ver Sellos
                                    </button>
                                 </td>
                                 <!--<td><?php echo e($load->carrier); ?></td>-->
                                 <td class="text-center"><?php echo e(date('d/m/Y', strtotime($load->date))); ?></td>
                                 <td class="text-center"><?php echo e(date('d/m/Y', strtotime($load->arrival_date))); ?></td>
                                 <td class="text-center"><?php echo e($load->code_deep); ?> - <?php echo e($load->brand_deep); ?></td>
                                 <td class="text-center"><?php echo e($load->code_door); ?> - <?php echo e($load->brand_door); ?></td>
                                 <td>
                                    <button 
                                       type="button" 
                                       class="btn btn-outline-info btn-sm test" 
                                       data-toggle="popover" 
                                       title="Clientes" 
                                       data-content="
                                       <?php $__currentLoopData = $coordination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($load->id == $item->id_load): ?>
                                             - <?php echo e(strtoupper(str_replace('SAG-', '', $item->name))); ?>

                                          <?php endif; ?>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       "
                                       >Ver Clientes
                                    </button>
                                 </td>
                                 <?php
                                    $totalCoord = 0;
                                    $totalEmbarq = 0;
                                 ?>
                                 <td class="text-center">
                                    <?php $__currentLoopData = $coordinacions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($load->id == $item->id_load): ?>
                                          <?php
                                             $totalCoord += $item->pieces;
                                          ?>
                                       <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($totalCoord); ?>

                                 </td>
                                 <td class="text-center">
                                    <?php $__currentLoopData = $palletItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($load->id == $item2->id_load): ?>
                                          <?php
                                             $totalEmbarq += $item2->quantity;
                                          ?>
                                       <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($totalEmbarq); ?>

                                 </td>
                                 <?php
                                    $fecha_actual = date("Y-m-d");
                                    /*$dias = date("d-m-Y",strtotime($fecha_actual."- 1 days"));*/
                                    $loadDate = new DateTime($load->date);
                                    $loadArrivalDate = new DateTime($load->arrival_date);
                                    $nowDate = new DateTime($fecha_actual);
                                    $totalTrip = $loadDate->diff($loadArrivalDate); // 14
                                    $advanced = $loadDate->diff($nowDate);
                                    
                                    if($advanced->d >= $totalTrip->d || $nowDate > $loadArrivalDate)
                                    {
                                       $percent = 100;
                                    }elseif($nowDate < $loadDate){
                                       $percent = 0;
                                    }else{
                                       $percent = $advanced->d*100/$totalTrip->d;
                                    }
                                 ?>
                                 <td>
                                    <p style="margin-bottom: 0"><code><?php if($percent == 100): ?> Entregado <?php elseif($percent == 0): ?> Próximo a salir <?php else: ?> En camino <?php endif; ?></code></p>
                                    <div class="progress">
                                       <div class="progress-bar <?php if($percent == 100): ?> bg-success <?php else: ?> bg-primary <?php endif; ?> progress-bar-striped" role="progressbar" aria-valuenow="<?php echo e($percent); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($percent); ?>%">
                                          <span class="sr-only"><?php echo e($percent); ?>% Complete (success)</span>
                                       </div>
                                    </div>
                                 </td>
                                 
                                 <!--<td>
                                    <div class="progress mb-3">
                                    <div class="progress-bar bg-success" role="progressbar" aria-valuenow="4" aria-valuemin="0" aria-valuemax="15" style="width: 5%">
                                      <span class="sr-only">40% Complete (success)</span>
                                    </div>
                                  </div>
                                 </td>-->
                                 <td width="45px" class="text-center">
                                    <!--<div class="btn-group">
                                       <a href="<?php echo e(route('load.show', $load->id)); ?>" type="button" class="btn btn-outline-success btn-sm"><i class="fas fa-eye"></i></a>
                                       <a href="<?php echo e(route('load.edit', $load->id)); ?>" type="button" class="btn btn-outline-warning btn-sm"><i class="fas fa-edit"></i></a>
                                       <?php echo e(Form::open(['route' => ['load.destroy', $load->id], 'method' => 'DELETE'])); ?>

                                          <?php echo e(Form::button('<i class="fas fa-trash-alt"></i> ' . '', ['type' => 'submit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'title' => 'Eliminar carga', 'class' => 'btn btn-sm btn-outline-danger', 'onclick' => 'return confirm("¿Seguro de eliminar la carga?")'])); ?>

                                       <?php echo e(Form::close()); ?>

                                     </div>-->
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'load.show')): ?>
                                       <a href="<?php echo e(route('load.show', $load->id)); ?>" class="btn btn-outline-success btn-sm"><i class="fas fa-eye"></i></a>
                                    <?php endif; ?>
                                 </td>
                                 <td width="45px" class="text-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'load.edit')): ?>
                                       <a href="<?php echo e(route('load.edit', $load->id)); ?>" class="btn btn-outline-warning btn-sm"><i class="fas fa-edit"></i></a>
                                    <?php endif; ?>
                                 </td>
                                 <td width="45px" class="text-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'load.destroy')): ?>
                                       <?php echo e(Form::open(['route' => ['load.destroy', $load->id], 'method' => 'DELETE'])); ?>

                                          <?php echo e(Form::button('<i class="fas fa-trash-alt"></i> ' . '', ['type' => 'submit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'title' => 'Eliminar carga', 'class' => 'btn btn-sm btn-outline-danger', 'onclick' => 'return confirm("¿Seguro de eliminar la carga?")'])); ?>

                                       <?php echo e(Form::close()); ?>

                                    <?php endif; ?>
                                 </td>
                              </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     </table>
                  </div>
                  <!-- /.card-body -->
               </div>
            <?php endif; ?>
            <!-- /.card -->
         </div>
      </div>
   </div>
</section>











<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
   <script>
      $(function () {
         $('.test').popover({
            container: 'body'
         })
      });
   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/load/index.blade.php ENDPATH**/ ?>