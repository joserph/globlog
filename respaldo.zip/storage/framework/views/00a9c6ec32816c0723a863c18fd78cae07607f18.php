<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'client.edit')): ?>
<h2>Editar cliente</h2>
<?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php echo $__env->make('client.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<button type="button" wire:click="update" class="btn btn-outline-warning">
    <i class="fas fa-sync"></i> Actualizar
</button>

<button wire:click="default" class="btn btn-outline-secondary">
    <i class="fas fa-ban"></i> Cancelar
</button>
<?php endif; ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/client/edit.blade.php ENDPATH**/ ?>