<div class="card-body" style="display: none;">
    <div class="table-responsive">
       <?php if($item->id_pallet): ?>
       <table class="table table-sm table table-bordered">
          <thead>
          <tr>
             <th class="text-center">Finca</th>
             <th class="text-center">Cliente</th>
             <th class="text-center">Piso</th>
             <th class="text-center">HB</th>
             <th class="text-center">QB</th>
             <th class="text-center">EB</th>
             <th class="text-center">Total</th>
          </tr>
          </thead>
          <tbody>
             <?php
                $hb = 0; $qb = 0; $eb = 0; $total = 0;
             ?>
             <?php $__currentLoopData = $palletsItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->id_pallet == $item2->id_pallet): ?>
                   <?php 
                      $hb+=$item2->hb;
                      $qb+=$item2->qb;
                      $eb+=$item2->eb;
                      $total+=$item2->quantity;
                   ?>
                   <tr>
                      <td>
                         <?php $__currentLoopData = $farms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item2->id_farm == $farm->id): ?>
                               <small><?php echo e(Str::limit(strtoupper($farm->name), '17')); ?></small>
                            <?php endif; ?>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </td>
                      <td class="text-center">
                         <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item2->id_client == $client->id): ?>
                               <small><?php echo e(Str::limit(str_replace('SAG-', '', $client->name), '8')); ?></small>
                            <?php endif; ?>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </td>
                      <td class="text-center">
                         <?php if($item2->piso == 1): ?>
                         <span class="badge badge-warning">SI</span>
                         <?php endif; ?>
                      </td>
                      <td class="text-center"><?php echo e($item2->hb); ?></td>
                      <td class="text-center"><?php echo e($item2->qb); ?></td>
                      <td class="text-center"><?php echo e($item2->eb); ?></td>
                      <td class="text-center"><?php echo e($item2->quantity); ?></td>
                   </tr>
                   
                <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
             <tr>
                <th colspan="3" class="text-center">Totales</th>
                <th class="text-center"><?php echo e($hb); ?></th>
                <th class="text-center"><?php echo e($qb); ?></th>
                <th class="text-center"><?php echo e($eb); ?></th>
                <th class="text-center"><?php echo e($total); ?></th>
             </tr>
         </tfoot>
       </table>
       <?php endif; ?>
    </div>
       
       
 </div><?php /**PATH C:\laragon\www\app-ffc\resources\views/sketches/partials/listPallet.blade.php ENDPATH**/ ?>