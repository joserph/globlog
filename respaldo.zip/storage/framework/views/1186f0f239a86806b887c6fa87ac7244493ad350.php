<div class="form-row">
   <div class="form-group col-md-2">
      <?php echo e(Form::label('shipment', 'Carga')); ?>

      <?php echo e(Form::text('shipment', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-4">
      <?php echo e(Form::label('bl', 'BL')); ?>

      <?php echo e(Form::text('bl', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-3">
      <?php echo e(Form::label('booking', 'Booking')); ?>

      <?php echo e(Form::text('booking', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-3">
      <?php echo e(Form::label('carrier', 'Transportista')); ?>

      <?php echo e(Form::text('carrier', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-4">
      <?php echo e(Form::label('id_logistic_company', 'Carguera')); ?>

      <?php echo e(Form::select('id_logistic_company', $logistics_companies, null, ['class' => 'form-control', 'placeholder' => 'Seleccione Carguera'])); ?>

   </div>
   <div class="form-group col-md-4">
      <?php echo e(Form::label('date', 'Fecha Salida')); ?>

      <?php echo e(Form::date('date', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-4">
      <?php echo e(Form::label('arrival_date', 'Fecha llegada')); ?>

      <?php echo e(Form::date('arrival_date', null, ['class' => 'form-control'])); ?>

   </div>
   
   <div class="form-group col-md-6">
      <?php echo e(Form::label('code_deep', 'Código Termografo Fondo')); ?>

      <?php echo e(Form::text('code_deep', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-6">
      <?php echo e(Form::label('brand_deep', 'Marca Termografo Fondo')); ?>

      <?php echo e(Form::text('brand_deep', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-6">
      <?php echo e(Form::label('code_door', 'Código Termografo Puerta')); ?>

      <?php echo e(Form::text('code_door', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-6">
      <?php echo e(Form::label('brand_door', 'Marca Termografo Puerta')); ?>

      <?php echo e(Form::text('brand_door', null, ['class' => 'form-control'])); ?>

   </div>

   <div class="form-group col-md-3">
      <?php echo e(Form::label('container_number', 'Número Contenedor')); ?>

      <?php echo e(Form::text('container_number', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-3">
      <?php echo e(Form::label('seal_bottle', 'Sello Botella')); ?>

      <?php echo e(Form::text('seal_bottle', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-3">
      <?php echo e(Form::label('seal_cable', 'Sello Cable')); ?>

      <?php echo e(Form::text('seal_cable', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-3">
      <?php echo e(Form::label('seal_sticker', 'Sello Sticker')); ?>

      <?php echo e(Form::text('seal_sticker', null, ['class' => 'form-control'])); ?>

   </div>
   <div class="form-group col-md-4">
      <?php echo e(Form::label('id_qa', 'Empresa QA')); ?>

      <?php echo e(Form::select('id_qa', $qacompanies, null, ['class' => 'form-control', 'placeholder' => 'Seleccione Carguera'])); ?>

   </div>
   <div class="form-group col-md-3">
      <?php echo e(Form::label('floor', 'Paletas al Piso')); ?>

      <?php echo e(Form::select('floor', [
         'si' => 'Si',
         'no' => 'No'
         ], null, ['class' => 'form-control', 'placeholder' => 'Paletas al Piso'])); ?>

   </div>
   <div class="form-group col-md-2" id="hide">
      <?php echo e(Form::label('num_pallets', 'Cantidad de paletas')); ?>

      <?php echo e(Form::number('num_pallets', null, ['class' => 'form-control'])); ?>

   </div>

   <?php echo e(Form::hidden('id_user', Auth::user()->id)); ?>

   <?php echo e(Form::hidden('update_user', Auth::user()->id)); ?>

</div>
    <?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/load/partials/form.blade.php ENDPATH**/ ?>