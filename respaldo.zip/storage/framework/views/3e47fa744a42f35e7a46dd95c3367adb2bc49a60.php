<div class="form-row">
    <div class="col-md-3 form-group finca">
        <?php echo e(Form::label('name', 'Nombre', ['class' => 'control-label'])); ?>

        <?php echo e(Form::text('name', null, ['class' => 'form-control select-farm', 'placeholder' => 'Nombre Comercializadora'])); ?>

    </div>
    <div class="col-md-9 form-group finca">
        <?php echo e(Form::label('clients', 'Clientes', ['class' => 'control-label'])); ?>

        <?php echo e(Form::text('clients', null, ['class' => 'form-control select-farm', 'placeholder' => 'Clientes'])); ?>

    </div>
    <?php echo e(Form::hidden('id_user', Auth::user()->id)); ?>

    <?php echo e(Form::hidden('update_user', Auth::user()->id)); ?>

 </div><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/marketer/partials/form.blade.php ENDPATH**/ ?>