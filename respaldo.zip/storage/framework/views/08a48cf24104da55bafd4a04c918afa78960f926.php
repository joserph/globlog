

<?php $__env->startSection('title'); ?> Empresas QA | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">    
   <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1>Empresas QA
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'qacompany.create')): ?>
                  <a href="<?php echo e(route('qacompany.create')); ?>" class="btn btn-outline-primary btn-sm"><i class="fas fa-plus-circle"></i></a>
               <?php endif; ?>
            </h1>
         </div>
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item active">Empresas QA</li>
            </ol>
         </div>
      </div>
   </div><!-- /.container-fluid -->
</section>

<section class="content">
   <div class="container-fluid">
      <div class="row">
         <!-- /.col -->
         <div class="col-md-12">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'qacompany.index')): ?>
               <div class="card">
                  <div class="card-header">
                     <h3 class="card-title">Lista de Empresas QA</h3>
                     <div class="card-tools">
                        <?php echo e($qa_companies->links()); ?>

                     </div>
                  </div>
   
                  <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
   
                  <div class="card-body">
                     <div class="table-responsive">
                        <table class="table table-sm" id="table-qacompany" style="width:100%">
                           <thead>
                              <tr>
                                 <th class="text-center" scope="col">Nombre</th>
                                 <th class="text-center" scope="col">Dueño</th>
                                 <th class="text-center" scope="col">Teléfono</th>
                                 <th class="text-center" scope="col">Correo</th>
                                 <th class="text-center" width="250px"><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'qacompany.edit')): ?>Editar <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'qacompany.destroy')): ?>Eliminar <?php endif; ?></th>
                              </tr>
                           </thead>
                           <tbody> 
                              <?php $__currentLoopData = $qa_companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr>
                                    <td class="text-center"><?php echo e(Str::upper($item->name)); ?></td>
                                    <td class="text-center"><?php echo e($item->owner); ?></td>
                                    <td class="text-center"><?php echo e($item->phone); ?></td>
                                    <td class="text-center"><?php echo e($item->email); ?></td>
                                    <td width="250px" class="text-center">
                                       
                                       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'qacompany.edit')): ?>
                                          <a href="<?php echo e(route('qacompany.edit', $item->id)); ?>" class="btn btn-outline-warning btn-sm"><i class="fas fa-edit"></i></a>
                                       <?php endif; ?>
                                       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'qacompany.destroy')): ?>
                                          <?php echo e(Form::open(['route' => ['qacompany.destroy', $item->id], 'method' => 'DELETE', 'style' => 'display: inline-block'])); ?>

                                             <?php echo e(Form::button('<i class="fas fa-trash-alt"></i> ' . '', ['type' => 'submit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'title' => 'Eliminar Empresa QA', 'class' => 'btn btn-sm btn-outline-danger', 'onclick' => 'return confirm("¿Seguro de eliminar la Empresa QA?")'])); ?>

                                          <?php echo e(Form::close()); ?>

                                       <?php endif; ?>
                                    </td>
                                 </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tbody>
                        </table>
                     </div>
                     
                  </div>
               </div>
            <?php endif; ?>
            <!-- /.card -->
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script>
       $(document).ready( function () {
            $('#table-qacompany').DataTable({
               "language": {
                     "lengthMenu": "Mostrar _MENU_ registros por página",
                     "zeroRecords": "No se encontró nada, lo siento",
                     "info": "Mostrando página _PAGE_ de _PAGES_",
                     "infoEmpty": "No hay registros disponibles",
                     "infoFiltered": "(filtrado de _MAX_ registros totales)",
                     "search": "Buscar:",
                     "pagingType": "full_numbers",
                     'paginate': {
                        'previous': 'Anterior',
                        'next': 'Siguiente'
                     }
               }
         });
      });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/qacompany/index.blade.php ENDPATH**/ ?>