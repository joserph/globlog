

<?php $__env->startSection('title'); ?> <?php echo e($load->bl); ?> - <?php echo e($load->shipment); ?> | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="container-fluid">
       <div class="row mb-2">
          <div class="col-sm-6">
             <h1><?php echo e($load->bl); ?> - <?php echo e($load->shipment); ?></h1>
          </div>
          <div class="col-sm-6">
             <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('load.index')); ?>">Cargas</a></li>
                <li class="breadcrumb-item active"><?php echo e($load->bl); ?></li>
             </ol>
          </div>
       </div>
    </div><!-- /.container-fluid -->
 </section>



<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            
            <!-- Factura Master -->
            <div class="row">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'masterinvoice.index')): ?>
                <div class="col-lg-3 col-6">
                  <!-- small card -->
                  <div class="small-box bg-info">
                    <div class="inner">
                      <h3><?php echo e($loadCount); ?></h3>
      
                      <p>Items de la factura</p>
                    </div>
                    <div class="icon">
                     <i class="fas fa-file-invoice-dollar"></i>
                    </div>
                     <a href="<?php echo e(route('masterinvoices.index', $load->id)); ?>" class="small-box-footer">
                      Ver Master Invoice <i class="fas fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'isf.index')): ?>
               <!-- ISF -->
               <div class="col-lg-3 col-6">
                 <!-- small card -->
                 <div class="small-box bg-success">
                   <div class="inner">
                     <h3><?php echo e($farmsCount); ?></h3>
     
                     <p>Fincas</p>
                   </div>
                   <div class="icon">
                     <i class="fas fa-file-alt"></i>
                   </div>
                    <a href="<?php echo e(route('isf.index', $load->id)); ?>" class="small-box-footer">
                     Ver ISF <i class="fas fa-arrow-circle-right"></i>
                   </a>
                 </div>
               </div>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'pallets.index')): ?>
               <!-- Plano de carga -->
               <div class="col-lg-3 col-6">
                <!-- small card -->
                <div class="small-box bg-warning">
                  <div class="inner">
                    <h3><?php echo e($palletsCount); ?></h3>
    
                    <p>Paletas</p>
                  </div>
                  <div class="icon">
                    <i class="fas fa-pallet"></i>
                  </div>
                   <a href="<?php echo e(route('pallets.index', $load->id)); ?>" class="small-box-footer">
                    Ver Paletas <i class="fas fa-arrow-circle-right"></i>
                  </a>
                </div>
              </div>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'coordination.index')): ?>
              <!-- Coordinaciones -->
              <div class="col-lg-3 col-6">
                <!-- small card -->
                <div class="small-box bg-primary">
                  <div class="inner">
                    <h3><?php echo e($coordinationCount); ?></h3>
    
                    <p>Fincas Coordinadas</p>
                  </div>
                  <div class="icon">
                    <i class="fas fa-grip-vertical"></i>
                  </div>
                   <a href="<?php echo e(route('coordination.index', $load->id)); ?>" class="small-box-footer">
                    Ver coordinaciones <i class="fas fa-arrow-circle-right"></i>
                  </a>
                </div>
              </div>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'sketches.index')): ?>
              <!-- Plano de carga -->
              <div class="col-lg-3 col-6">
                <!-- small card -->
                <div class="small-box bg-secondary">
                  <div class="inner">
                    <h3><?php echo e($palletsCount); ?></h3>
    
                    <p>Plano de Carga</p>
                  </div>
                  <div class="icon">
                    <i class="fas fa-trailer"></i>
                  </div>
                   <a href="<?php echo e(route('sketches.index', $load->id)); ?>" class="small-box-footer">
                    Ver Plano de carga <i class="fas fa-arrow-circle-right"></i>
                  </a>
                </div>
              </div>
              <?php endif; ?>
           </div>

        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/load/show.blade.php ENDPATH**/ ?>