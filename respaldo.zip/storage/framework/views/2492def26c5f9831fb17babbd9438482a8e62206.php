

<?php $__env->startSection('title'); ?> Lista de Role(s) | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1>Role(s)
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'role.create')): ?>
                  <a href="<?php echo e(route('role.create')); ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus-circle"></i> Crear</a>
               <?php endif; ?>
            </h1>
         </div>
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item active">Role(s)</li>
            </ol>
         </div>
      </div>
   </div><!-- /.container-fluid -->
</section>

  <!-- Main content -->
<section class="content">
   <div class="container-fluid">
      <div class="row">
         <!-- /.col -->
         <div class="col-md-12">
            <div class="card">
               <div class="card-header">
                  Lista de roles

                  <div class="card-tools">
                     <?php echo e($roles->links()); ?>

                  </div>
               </div>

               <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

               <!-- /.card-header -->
               <div class="card-body table-responsive p-0">
                  <table class="table">
                     <thead>
                        <tr>
                           <th class="text-center" scope="col">#</th>
                           <th class="text-center" scope="col">Nombre</th>
                           <th class="text-center" scope="col">Slug</th>
                           <th class="text-center" scope="col">Descripción</th>
                           <th class="text-center" scope="col">Full Acceso</th>
                           <th class="text-center" colspan="3">&nbsp;</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td class="text-center"><?php echo e($role->id); ?></td>
                           <td class="text-center"><?php echo e($role->name); ?></td>
                           <td class="text-center"><?php echo e($role->slug); ?></td>
                           <td class="text-center"><?php echo e($role->description); ?></td>
                           <?php if($role->full_access === 'no'): ?>
                              <td class="text-center"><span class="badge bg-warning"><?php echo e($role->full_access); ?></span></td>
                           <?php else: ?>
                              <td class="text-center"><span class="badge bg-success"><?php echo e($role->full_access); ?></span></td>
                           <?php endif; ?>

                           <td width="100px" class="text-center">
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'role.show')): ?>
                                 <a href="<?php echo e(route('role.show', $role->id)); ?>" class="btn btn-info btn-sm"><i class="fas fa-eye"></i> Ver</a>
                              <?php endif; ?>
                           </td>
                           <td width="100px" class="text-center">
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'role.edit')): ?>
                                 <a href="<?php echo e(route('role.edit', $role->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Editar</a>
                              <?php endif; ?>
                           </td>
                           <td width="120px" class="text-center">
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'role.destroy')): ?>
                                 <?php echo e(Form::open(['route' => ['role.destroy', $role->id], 'method' => 'DELETE'])); ?>

                                    <?php echo e(Form::button('<i class="fas fa-trash-alt"></i> ' . 'Eliminar', ['type' => 'submit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'title' => 'Eliminar cliente', 'class' => 'btn btn-sm btn-danger', 'onclick' => 'return confirm("¿Seguro de eliminar el role?")'])); ?>

                                 <?php echo e(Form::close()); ?>

                              <?php endif; ?>
                           </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                  </table>
               </div>
               <!-- /.card-body -->
            </div>
            <!-- /.card -->
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-ffc\resources\views/role/index.blade.php ENDPATH**/ ?>