<div class="row">
   <div class="col-md-4 form-group">
      <?php echo e(Form::label('', 'N° Carga', ['class' => 'control-label'])); ?>

      <input type="text" class="form-control" value="<?php echo e($load->shipment); ?>" readonly>
      <input type="hidden" name="id_load" class="form-control" value="<?php echo e($load->id); ?>">
   </div>
   <div class="col-md-4 form-group">
      <?php echo e(Form::label('', 'BL', ['class' => 'control-label'])); ?>

      <input type="text" class="form-control" name="bl" value="<?php echo e($load->bl); ?>" readonly>
   </div>
   <div class="col-md-4 form-group">
      <?php echo e(Form::label('', 'Mi Empresa', ['class' => 'control-label'])); ?>

      <input type="text" name="" class="form-control" value="<?php echo e($company->name); ?>" readonly>
      <input type="hidden" class="form-control" value="<?php echo e($company->id); ?>" name="id_company">
   </div>
   <div class="col-md-4 form-group">
      <?php echo e(Form::label('id_logistics_company', 'Empresa de Logística', ['class' => 'control-label'])); ?>

      <input type="text" name="" class="form-control" value="<?php echo e($lc_active->name); ?>" readonly>
      <input type="hidden" class="form-control" value="<?php echo e($lc_active->id); ?>" name="id_logistics_company">
   </div>
   <div class="col-md-4 form-group">
      <?php echo e(Form::label('invoice', 'N° de Factura', ['class' => 'control-label'])); ?>

      <input type="text" name="invoice" class="form-control <?php $__errorArgs = ['invoice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="invoice">
   </div>
   <div class="col-md-4 form-group">
      <?php echo e(Form::label('date', 'Fecha', ['class' => 'control-label'])); ?>

      <input type="date" name="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="date">
   </div>
   <?php echo e(Form::hidden('id_user', Auth::user()->id )); ?>

   <?php echo e(Form::hidden('update_user', Auth::user()->id )); ?>

   <?php echo e(Form::hidden('carrier', $load->carrier )); ?>

</div><?php /**PATH C:\laragon\www\app-ffc\resources\views/masterinvoice/formHeader.blade.php ENDPATH**/ ?>