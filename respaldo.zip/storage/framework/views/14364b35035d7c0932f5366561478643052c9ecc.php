<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'company.index')): ?>
<h2>Mi Empresa</h2>
<div class="table-responsive">
   <table class="table table-sm table-hover">
    <thead>
       <tr>
          <th scope="col">Nombre</th>
          <th scope="col">Teléfono</th>
          <th scope="col">Dirección</th>
          <th scope="col">Estado</th>
          <th scope="col">Ciudad</th>
          <th scope="col">País</th>
          <th class="text-center" colspan="2"><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'company.edit')): ?> Editar <?php endif; ?>  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'company.destroy')): ?>/ Eliminar <?php endif; ?></th>
       </tr>
    </thead>
    <tbody>
       <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($company->name); ?></td>
            <td><?php echo e($company->phone); ?></td>
            <td><?php echo e($company->address); ?></td>
            <td><?php echo e($company->state); ?></td>
            <td><?php echo e($company->city); ?></td>
            <td><?php echo e($company->country); ?></td>
            <td colspan="2" class="text-center">
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'company.edit')): ?>
               <button wire:click="edit(<?php echo e($company->id); ?>)" class="btn btn-sm btn-outline-warning">
                  <i class="far fa-edit"></i>
               </button>
               <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'company.destroy')): ?>
               <button wire:click="destroy(<?php echo e($company->id); ?>)" class="btn btn-sm btn-outline-danger">
                  <i class="fas fa-trash"></i>
               </button>
               <?php endif; ?>
            </td>
         </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
 </table>
 <?php echo e($companies->links()); ?>

</div>
<?php endif; ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/company/table.blade.php ENDPATH**/ ?>