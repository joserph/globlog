

<?php $__env->startSection('title'); ?> Lista de Permisos | Sistema de Carguera v1.1 <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">    
   <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css">    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1>Permisos
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'permission.create')): ?>
                  <a href="<?php echo e(route('permission.create')); ?>" class="btn btn-outline-primary btn-sm"><i class="fas fa-plus-circle"></i></a>
               <?php endif; ?>
            </h1>
         </div>
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item active">Permisos</li>
            </ol>
         </div>
      </div>
   </div><!-- /.container-fluid -->
</section>

<section class="content">
   <div class="container-fluid">
      <div class="row">
         <!-- /.col -->
         <div class="col-md-12">
            <div class="card">
               <div class="card-header">
                  <h3 class="card-title"><i class="fas fa-user-lock"></i> Lista de Permisos</h3>
                  
               </div>
 
               <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
 
               <!-- /.card-header -->
               <div class="card-body">
                  <div class="table-responsive">
                     <table class="table table-sm" id="permission-table" style="width:100%">
                        <thead>
                           <tr>
                              <th class="text-center" scope="col">#</th>
                              <th scope="col">Nombre</th>
                              <th scope="col">Slug</th>
                              <th scope="col">Descripción</th>
                              
                              
                              <th class="text-center" width="250px"><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'permission.show')): ?>Ver <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'permission.edit')): ?>Editar <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'permission.destroy')): ?>Eliminar <?php endif; ?></th>
                           </tr>
                        </thead>
                        <tbody> 
                           <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                 <td class="text-center"><?php echo e($permission->id); ?></td>
                                 <td><?php echo e($permission->name); ?></td>
                                 <td><?php echo e($permission->slug); ?></td>
                                 <td><?php echo e($permission->description); ?></td>
                                 <td width="250px" class="text-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'permission.show')): ?>
                                       <a href="<?php echo e(route('permission.show', $permission->id)); ?>" class="btn btn-outline-info btn-sm"><i class="fas fa-eye"></i></a>
                                    <?php endif; ?>
                                 
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'permission.edit')): ?>
                                       <a href="<?php echo e(route('permission.edit', $permission->id)); ?>" class="btn btn-outline-warning btn-sm"><i class="fas fa-edit"></i></a>
                                    <?php endif; ?>
                                 
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('haveaccess', 'permission.destroy')): ?>
                                       <?php echo e(Form::open(['route' => ['permission.destroy', $permission->id], 'method' => 'DELETE', 'style' => 'display: inline-block'])); ?>

                                          <?php echo e(Form::button('<i class="fas fa-trash-alt"></i> ' . '', ['type' => 'submit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'title' => 'Eliminar permiso', 'class' => 'btn btn-sm btn-outline-danger', 'onclick' => 'return confirm("¿Seguro de eliminar el permiso?")'])); ?>

                                       <?php echo e(Form::close()); ?>

                                    <?php endif; ?>
                                 </td>
                              </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     </table>
                  </div>
                  
               </div>
               <div class="card-footer">
                  
               </div>
               <!-- /.card-body -->
            </div>
            <!-- /.card -->
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
    <script>
       /*$(document).ready(function(){
         $('#permission-table').DataTable({
            processing: true,
            serverSiver: true,
            ajax: '<?php echo route('dataTablePermission'); ?>',
            columns: [
               {data: 'id'},
               {data: 'name'},
               {data: 'slug'},
               {data: 'description'},
               {data: 'created_at'},
               {data: 'btn'}
               //{data: 'show'},
               //{data: 'edit'}
            ]
         });
       });*/

       $(document).ready( function () {
            $('#permission-table').DataTable({
               "language": {
                     "lengthMenu": "Mostrar _MENU_ registros por página",
                     "zeroRecords": "No se encontró nada, lo siento",
                     "info": "Mostrando página _PAGE_ de _PAGES_",
                     "infoEmpty": "No hay registros disponibles",
                     "infoFiltered": "(filtrado de _MAX_ registros totales)",
                     "search": "Buscar:",
                     "pagingType": "full_numbers",
                     'paginate': {
                        'previous': 'Anterior',
                        'next': 'Siguiente'
                     }
               }
         });
      });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u381130168/domains/joserph.com/public_html/ffc/resources/views/permission/index.blade.php ENDPATH**/ ?>