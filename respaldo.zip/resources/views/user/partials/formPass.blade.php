<div class="form-group row">
    <label for="mypassword" class="col-sm-4 control-label">Contraseña actual</label>
    <div class="col-sm-8">
        <input type="password" name="mypassword" id="" class="form-control">
    </div>
</div>
<div class="form-group row">
    <label for="password" class="col-sm-4 control-label">Nueva contraseña</label>
    <div class="col-sm-8">
        <input type="password" name="password" id="" class="form-control">
    </div>
</div>
<div class="form-group row">
    <label for="password_confirmation" class="col-sm-4 control-label">Confirmar nueva contraseña</label>
    <div class="col-sm-8">
        <input type="password" name="password_confirmation" id="" class="form-control">
    </div>
</div>