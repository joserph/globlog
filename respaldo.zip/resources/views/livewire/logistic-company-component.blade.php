<div class="row">
    <div class="col-md-12">
        @include("logistic.$view")
    </div>
    <div class="col-md-12">
        <hr>
    </div>
    <div class="col-md-12">
        @include('logistic.table')
    </div>
</div>
