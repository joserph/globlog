<template>
    <div>
        <h1>Mi componente</h1>
    </div>
</template>

<script>
    export default {
        
    }
</script>
