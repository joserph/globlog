<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Farm;
use Faker\Generator as Faker;

$factory->define(Farm::class, function (Faker $faker) {
    return [
        //
    ];
});
