<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ComercialInvoiceItemComponent extends Component
{   
    public $hola;
    public function render()
    {
        /*$hola = 'hola mundo';
        return view('masterinvoice.index',[
            'hola' => $hola
        ]);*/
    }
}
