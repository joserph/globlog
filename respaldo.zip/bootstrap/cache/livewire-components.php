<?php return array (
  'client-component' => 'App\\Http\\Livewire\\ClientComponent',
  'comercial-invoice-item-component' => 'App\\Http\\Livewire\\ComercialInvoiceItemComponent',
  'company-component' => 'App\\Http\\Livewire\\CompanyComponent',
  'farm-component' => 'App\\Http\\Livewire\\FarmComponent',
  'logistic-company-component' => 'App\\Http\\Livewire\\LogisticCompanyComponent',
  'variety-component' => 'App\\Http\\Livewire\\VarietyComponent',
);